import sys, subprocess, traceback, platform, time, os, math, json, base64, urllib.request, urllib.error, urllib.parse
from pathlib import Path

APP='TIGER 3D AI'
VERSION='v1.6.0 TURBO CPU + Gemini + Atualizador GitHub'
BASE=Path(__file__).resolve().parent
UPDATE_CONFIG_FILE=BASE/'update_config.json'
TRIPOSR=BASE/'TripoSR'
OUTPUT=BASE/'output_ai'
OUTPUT.mkdir(exist_ok=True)
PREP=OUTPUT/'preprocessed'
PREP.mkdir(exist_ok=True)


def errbox(t,m):
    try:
        from PySide6.QtWidgets import QMessageBox
        QMessageBox.critical(None,t,m)
    except Exception:
        print(t+'\n'+m)

try:
    import numpy as np
    import trimesh
    import pyvista as pv
    from PySide6.QtWidgets import (
        QApplication,QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,QPushButton,QLabel,
        QFileDialog,QMessageBox,QDoubleSpinBox,QGroupBox,QFormLayout,QStatusBar,
        QTabWidget,QTextEdit,QProgressBar,QComboBox,QSplitter,QFrame,QCheckBox,
        QSpinBox,QSlider,QScrollArea,QLineEdit
    )
    from PySide6.QtGui import QPixmap
    from PySide6.QtCore import Qt,QThread,Signal,QTimer
    from pyvistaqt import QtInteractor
except Exception:
    errbox(APP+' — dependência ausente','Execute INSTALAR_TIGER_312.bat primeiro.\n\n'+traceback.format_exc())
    sys.exit(1)


def _update_config():
    default={'manifest_url':'https://raw.githubusercontent.com/oliveiracosta2026/TIGER-3D-AI-UPDATES/main/update.json','check_on_startup':True,'channel':'stable'}
    try:
        if UPDATE_CONFIG_FILE.exists():
            data=json.loads(UPDATE_CONFIG_FILE.read_text(encoding='utf-8'))
            if isinstance(data,dict):
                default.update(data)
    except Exception:
        pass
    return default


def _launch_updater(check_only=False):
    updater=BASE/'atualizador.py'
    if not updater.exists():
        raise RuntimeError('atualizador.py não foi encontrado na instalação.')
    args=[sys.executable,str(updater),'--app-dir',str(BASE)]
    if check_only: args.append('--check-only')
    return subprocess.Popen(args, cwd=str(BASE), creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))


def _schedule_update_check(parent):
    cfg=_update_config()
    url=str(cfg.get('manifest_url') or '').strip()
    if not url or 'SEU_USUARIO' in url:
        return
    try:
        _launch_updater(check_only=True)
    except Exception as e:
        try: parent.statusBar().showMessage('Atualização: '+str(e))
        except Exception: pass


def mesh_from_file(path):
    x=trimesh.load(path,force='scene')
    if isinstance(x,trimesh.Trimesh): return x.copy()
    if isinstance(x,trimesh.Scene):
        gs=[g for g in x.geometry.values() if isinstance(g,trimesh.Trimesh)]
        if gs:return trimesh.util.concatenate(gs).copy()
    raise RuntimeError('O arquivo não contém uma malha 3D reconhecível.')


def preprocess_image(src, dst, remove_bg=True, enhance=True, square=True):
    """Prepara uma imagem para o motor 3D: remove fundo, recorta, melhora contraste/nitidez e centraliza."""
    from PIL import Image, ImageEnhance, ImageOps
    img=Image.open(src).convert('RGBA')
    if remove_bg:
        try:
            from rembg import remove
            img=remove(img)
        except Exception:
            pass
    alpha=img.getchannel('A')
    bbox=alpha.getbbox()
    if bbox:
        l,t,r,b=bbox
        pad=max(12,int(max(r-l,b-t)*0.08))
        l=max(0,l-pad); t=max(0,t-pad); r=min(img.width,r+pad); b=min(img.height,b+pad)
        img=img.crop((l,t,r,b))
    if enhance:
        alpha=img.getchannel('A')
        rgb=img.convert('RGB')
        rgb=ImageEnhance.Contrast(rgb).enhance(1.08)
        rgb=ImageEnhance.Sharpness(rgb).enhance(1.22)
        img=rgb.convert('RGBA'); img.putalpha(alpha)
    if square:
        side=max(img.width,img.height)
        pad_x=(side-img.width)//2; pad_y=(side-img.height)//2
        canvas=Image.new('RGBA',(side,side),(0,0,0,0))
        canvas.alpha_composite(img,(pad_x,pad_y)); img=canvas
    # Normaliza o lado para manter o recorte consistente sem aumentar demais a carga do CPU.
    if max(img.size)>1024:
        img.thumbnail((1024,1024),Image.Resampling.LANCZOS)
    img.save(dst)
    return str(dst)


def image_to_relief(src, dst, resolution=192, base_mm=2.5, relief_mm=5.0, invert=False):
    """Cria um STL de alto-relevo a partir de uma imagem. É um modo local, sem IA, útil para logos/placas."""
    from PIL import Image, ImageOps, ImageEnhance
    img=Image.open(src).convert('RGBA')
    alpha=np.asarray(img.getchannel('A').resize((resolution,resolution),Image.Resampling.LANCZOS),dtype=np.float32)/255.0
    gray=np.asarray(ImageOps.grayscale(img).resize((resolution,resolution),Image.Resampling.LANCZOS),dtype=np.float32)/255.0
    # Mistura luminância e alpha para evitar que o fundo removido vire relevo.
    h=gray*alpha
    if invert: h=1.0-h
    h=ImageEnhance.Contrast(Image.fromarray(np.uint8(np.clip(h,0,1)*255))).enhance(1.12)
    h=np.asarray(h,dtype=np.float32)/255.0
    xs=np.linspace(-50,50,resolution); ys=np.linspace(-50,50,resolution)
    X,Y=np.meshgrid(xs,ys)
    Z=base_mm + relief_mm*h
    n=resolution
    verts=[]; faces=[]
    for j in range(n):
        for i in range(n): verts.append((float(X[j,i]),float(Y[j,i]),float(Z[j,i])))
    # Base inferior completa: mantém o relevo retangular e fechado.
    base_idx=len(verts)
    for j in range(n):
        for i in range(n): verts.append((float(X[j,i]),float(Y[j,i]),0.0))
    def idx(i,j): return j*n+i
    for j in range(n-1):
        for i in range(n-1):
            a,b,c,d=idx(i,j),idx(i+1,j),idx(i+1,j+1),idx(i,j+1)
            faces += [(a,b,c),(a,c,d)]
            a2,b2,c2,d2=base_idx+a,base_idx+b,base_idx+c,base_idx+d
            faces += [(a2,c2,b2),(a2,d2,c2)]
    # Paredes laterais.
    for i in range(n-1):
        for a,b in [(idx(i,0),idx(i+1,0)),(idx(i,n-1),idx(i+1,n-1))]:
            aa=base_idx+a; bb=base_idx+b; faces += [(a,bb,b),(a,aa,bb)]
    for j in range(n-1):
        for a,b in [(idx(0,j),idx(0,j+1)),(idx(n-1,j),idx(n-1,j+1))]:
            aa=base_idx+a; bb=base_idx+b; faces += [(a,b,bb),(a,bb,aa)]
    mesh=trimesh.Trimesh(vertices=np.asarray(verts),faces=np.asarray(faces),process=True)
    mesh.remove_unreferenced_vertices(); mesh.fix_normals(); mesh.export(dst,file_type='stl')
    return str(dst)



def auto_upright_figure(mesh):
    """Orienta uma figura usando candidatos PCA e escolhe a postura mais plausível.
    É uma heurística geométrica: não entende anatomia nem substitui IA visual."""
    m0=mesh.copy()
    if len(m0.vertices) < 4:
        return m0
    v=np.asarray(m0.vertices,dtype=np.float64)
    q=v-v.mean(axis=0)
    cov=np.cov(q.T)
    vals,vecs=np.linalg.eigh(cov)
    order=np.argsort(vals)[::-1]
    best=None
    # Tenta cada eixo principal como vertical e os dois sentidos. Depois faz pequenos giros em Z.
    for idx in order:
        axis=vecs[:,idx]
        for sign in (1.0,-1.0):
            a=axis*sign
            try:
                T=trimesh.geometry.align_vectors(a,[0,0,1])
                if T is None: continue
                cand=m0.copy(); cand.apply_transform(T)
                # Mantém o centro XY e apoia no chão para avaliar a silhueta.
                b=cand.bounds
                cand.apply_translation([-float((b[0,0]+b[1,0])/2),-float((b[0,1]+b[1,1])/2),-float(b[0,2])])
                ext=np.asarray(cand.extents,dtype=float)
                footprint=max(ext[0],ext[1],1e-6)
                aspect=ext[2]/footprint
                # Penaliza objetos excessivamente achatados e favorece eixo vertical alto.
                score=aspect
                if aspect>5: score-=0.5*(aspect-5)
                if best is None or score>best[0]: best=(score,cand)
            except Exception:
                continue
    if best is None:
        return m0
    return best[1]


def build_professional_base(diameter, height):
    """Base em dois estágios para aparência de produto e maior área de apoio."""
    d=max(float(diameter),20.0); h=max(float(height),2.0)
    lower_h=h*0.62; upper_h=h-lower_h
    lower=trimesh.creation.cylinder(radius=d/2.0,height=lower_h,sections=128)
    upper_d=d*0.88
    upper=trimesh.creation.cylinder(radius=upper_d/2.0,height=upper_h,sections=128)
    lower.apply_translation([0,0,lower_h/2.0])
    upper.apply_translation([0,0,lower_h+upper_h/2.0])
    return trimesh.util.concatenate([lower,upper])


def mesh_quality_report(mesh, expected_height=None, base_d=None):
    """Relatório técnico local de imprimibilidade. Não mede semelhança facial."""
    m=mesh
    s=np.asarray(m.extents,dtype=float)
    lines=['🧠 VERIFICAÇÃO IA 3D — LOCAL','']
    try:
        comps=m.split(only_watertight=False); ncomp=len(comps)
    except Exception:
        ncomp=1
    wat=bool(m.is_watertight)
    finite=bool(np.isfinite(np.asarray(m.vertices)).all())
    zmin=float(m.bounds[0,2]); zmax=float(m.bounds[1,2])
    contact_tol=max(0.25,float(s[2])*0.005)
    bottom=np.asarray(m.vertices)[:,2] <= zmin+contact_tol
    contact_count=int(np.count_nonzero(bottom))
    footprint=max(float(s[0]),float(s[1]))
    lines.append(('✅' if finite else '❌')+' Coordenadas da malha: '+('OK' if finite else 'INVÁLIDAS'))
    lines.append(('✅' if wat else '⚠️')+' Malha fechada (watertight): '+('SIM' if wat else 'NÃO'))
    comp_ok = (ncomp==1) or (base_d is not None and ncomp<=2)
    comp_note = ' (figura + base)' if base_d is not None and ncomp==2 else ''
    lines.append(('✅' if comp_ok else '⚠️')+f' Componentes geométricos: {ncomp}{comp_note}')
    lines.append(('✅' if abs(zmin) <= contact_tol+1e-6 else '⚠️')+f' Apoio no plano Z=0: z mínimo {zmin:.2f} mm')
    lines.append(('✅' if contact_count>=3 else '⚠️')+f' Pontos próximos da base: {contact_count:,}')
    if expected_height is not None:
        # Para peça com base, a altura total pode exceder o boneco alguns mm.
        delta=abs(float(s[2])-float(expected_height))
        ok=delta <= max(5.0,float(expected_height)*0.12)
        lines.append(('✅' if ok else '⚠️')+f' Altura atual: {s[2]:.1f} mm • alvo aproximado: {float(expected_height):.1f} mm')
    if base_d is not None:
        ok=footprint <= float(base_d)*1.15
        lines.append(('✅' if ok else '⚠️')+f' Ocupação XY: {footprint:.1f} mm • base configurada: {float(base_d):.1f} mm')
    try:
        if len(m.faces) <= 500000:
            broken=not bool(m.is_winding_consistent)
            lines.append(('⚠️' if broken else '✅')+' Orientação das faces: '+('REVISAR' if broken else 'CONSISTENTE'))
    except Exception:
        pass
    lines += ['',f'Dimensões: {s[0]:.1f} × {s[1]:.1f} × {s[2]:.1f} mm',f'Faces: {len(m.faces):,} • Vértices: {len(m.vertices):,}',
              '', 'ℹ️ Semelhança facial, roupa e fidelidade à foto ainda não são avaliadas pela IA local. Essa etapa será ligada à IA online.']
    return '\n'.join(lines)

def apply_creation_preset(mesh, mode, height_mm=100.0, base_on=True, base_d=60.0, base_h=5.0,
                          keyring_on=True, keyring_d=10.0, keyring_thickness=3.0, auto_upright=True):
    """Aplica um preset de produto imprimível sobre a malha gerada localmente."""
    m=mesh.copy()
    if len(m.vertices)==0 or len(m.faces)==0:
        raise RuntimeError('A IA gerou uma malha vazia.')
    # Figuras humanas costumam sair inclinadas do reconstrutor single-view.
    if auto_upright and mode.lower() in ('boneco personalizado','busto','miniatura'):
        m=auto_upright_figure(m)
    # Normaliza para uma dimensão previsível e apoia no plano Z=0.
    ext=m.extents
    if mode.lower()=='medalhão':
        xy=max(float(ext[0]),float(ext[1]),1e-6)
        target=max(float(base_d),20.0)
        m.apply_scale(target/xy)
    else:
        z=float(ext[2]) if float(ext[2])>1e-6 else max(float(max(ext)),1.0)
        target=float(height_mm)
        m.apply_scale(target/z)
    b=m.bounds.copy()
    center_xy=(float((b[0,0]+b[1,0])/2), float((b[0,1]+b[1,1])/2))
    m.apply_translation([-center_xy[0],-center_xy[1],-float(b[0,2])])

    parts=[m]
    mode_key=mode.lower()
    if mode_key in ('boneco personalizado','busto','miniatura') and base_on:
        # Respeita o diâmetro escolhido pelo usuário. A verificação técnica avisa se a peça ultrapassar.
        md=float(max(base_d,20.0))
        base=build_professional_base(md,float(base_h))
        # Faz o personagem penetrar levemente na base para eliminar a junta visual.
        m.apply_translation([0,0,float(base_h)-0.9])
        parts=[m,base]
    elif mode_key=='chaveiro' and keyring_on:
        # Aro separado, pronto para ser impresso junto. O eixo do furo é Z.
        b=m.bounds.copy(); w=float(m.extents[0]); d=float(m.extents[1]); top=float(b[1,2])
        ring=trimesh.creation.annulus(r_min=float(keyring_d)/2.0,
                                      r_max=float(keyring_d)/2.0+float(keyring_thickness),
                                      height=max(1.2,float(keyring_thickness)/2.0), sections=64)
        ring.apply_translation([0, min(float(b[1,1])+float(keyring_d)*0.65, d/2+keyring_d), top-float(keyring_d)*0.35])
        parts=[m,ring]
    elif mode_key=='medalhão':
        # Medalhão: usa a malha como relevo/arte e acrescenta uma base circular fina.
        md=max(float(base_d),float(max(m.extents[0],m.extents[1])*1.10))
        disk=trimesh.creation.cylinder(radius=md/2.0, height=max(2.5,float(base_h)), sections=128)
        disk.apply_translation([0,0,max(1.25,float(base_h)/2.0)])
        m.apply_translation([0,0,max(1.25,float(base_h))-0.4])
        parts=[m,disk]
    else:
        # Relevo local já é uma peça fechada; demais modos sem base seguem sem componentes extras.
        parts=[m]
    out=trimesh.util.concatenate(parts)
    out.remove_unreferenced_vertices(); out.fix_normals()
    return out


def interpret_tiger_command(text):
    """Interpreta comandos simples em português sem depender de IA online."""
    import re
    t=(text or '').lower().strip()
    cfg={}
    if not t: return cfg
    if any(k in t for k in ('boneco','boneca','figura','personagem')): cfg['mode']='Boneco personalizado'
    elif 'busto' in t: cfg['mode']='Busto'
    elif 'chaveiro' in t: cfg['mode']='Chaveiro'
    elif 'medalhão' in t or 'medalhao' in t: cfg['mode']='Medalhão'
    elif 'relevo' in t: cfg['mode']='Relevo'
    elif 'miniatura' in t: cfg['mode']='Miniatura'
    m=re.search(r'(?:com|de|altura(?: de)?|tamanho(?: de)?)\s*(\d+(?:[\.,]\d+)?)\s*(cm|mm)?',t)
    if m:
        val=float(m.group(1).replace(',','.')); unit=m.group(2) or 'cm'; cfg['height']=val*(10 if unit=='cm' else 1)
    m=re.search(r'(?:base|di[aâ]metro da base)\s*(?:de|com)?\s*(\d+(?:[\.,]\d+)?)\s*(cm|mm)?',t)
    if m:
        val=float(m.group(1).replace(',','.')); unit=m.group(2) or 'mm'; cfg['base_d']=val*(10 if unit=='cm' else 1)
    m=re.search(r'(?:nome|escrito|escreva|texto)\s*(?:na base|:)?\s*["“]?([\wÀ-ÿ ._-]{2,30})["”]?$',text.strip(),re.I)
    if m: cfg['name']=m.group(1).strip()
    if any(k in t for k in ('sem base','sem a base','não quero base','nao quero base')): cfg['base_on']=False
    if any(k in t for k in ('base','com base')): cfg.setdefault('base_on',True)
    if 'cartoon' in t: cfg['style']='Cartoon'
    elif 'chibi' in t: cfg['style']='Chibi'
    elif 'estátua' in t or 'estatua' in t: cfg['style']='Estátua'
    elif 'realista' in t: cfg['style']='Realista'
    return cfg



VERSION='v1.6.0 TURBO CPU + Gemini + Atualizador GitHub'
GEMINI_DEFAULT_MODEL='gemini-3.5-flash-lite'
GEMINI_CONFIG_DIR=Path(os.getenv('APPDATA') or (Path.home()/'.config'))/'TIGER3D_AI'
GEMINI_CONFIG_FILE=GEMINI_CONFIG_DIR/'gemini.json'

def _gemini_key_from_config():
    try:
        if GEMINI_CONFIG_FILE.exists():
            data=json.loads(GEMINI_CONFIG_FILE.read_text(encoding='utf-8'))
            return str(data.get('api_key','')).strip()
    except Exception:
        pass
    return ''

def _gemini_output_text(data):
    """Extrai texto de respostas Interactions e GenerateContent."""
    texts=[]
    for step in data.get('steps',[]) or []:
        if isinstance(step,dict) and step.get('type') == 'model_output':
            for item in step.get('content',[]) or []:
                if isinstance(item,dict) and item.get('type') == 'text' and item.get('text'):
                    texts.append(str(item['text']))
    if texts:
        return '\n'.join(texts).strip()
    if data.get('output_text'):
        return str(data['output_text']).strip()
    for item in data.get('output',[]) or []:
        if isinstance(item,dict) and item.get('type') == 'text' and item.get('text'):
            texts.append(str(item['text']))
    if texts:
        return '\n'.join(texts).strip()
    # GenerateContent: candidates[].content.parts[].text
    for cand in data.get('candidates',[]) or []:
        content=cand.get('content',{}) if isinstance(cand,dict) else {}
        for part in content.get('parts',[]) or []:
            if isinstance(part,dict) and part.get('text'):
                texts.append(str(part['text']))
    if texts:
        return '\n'.join(texts).strip()
    raise RuntimeError('Gemini respondeu sem texto utilizável: '+json.dumps(data,ensure_ascii=False)[:3000])


def _gemini_error_message(body):
    try:
        obj=json.loads(body)
        err=obj.get('error',{}) if isinstance(obj,dict) else {}
        if isinstance(err,dict):
            return str(err.get('message') or err.get('status') or body)
    except Exception:
        pass
    return str(body or 'erro desconhecido')


def _gemini_request(req, retries=2):
    """HTTP robusto: repete apenas falhas transitórias (429/5xx)."""
    last=None
    for attempt in range(retries+1):
        try:
            with urllib.request.urlopen(req,timeout=120) as resp:
                return json.loads(resp.read().decode('utf-8'))
        except urllib.error.HTTPError as e:
            body=e.read().decode('utf-8','ignore')
            last=(e.code,body)
            if e.code in (429,500,502,503,504) and attempt < retries:
                wait=2.0*(attempt+1)
                try: wait=max(wait,float(e.headers.get('Retry-After','0')))
                except Exception: pass
                time.sleep(min(wait,8.0))
                continue
            raise
        except (urllib.error.URLError, TimeoutError) as e:
            last=e
            if attempt < retries:
                time.sleep(1.5*(attempt+1)); continue
            raise
    raise RuntimeError(str(last))


def _gemini_generate_content(api_key, model, contents, max_tokens=1200, system_instruction=None):
    """Fallback compatível com a API generateContent oficial."""
    url=f'https://generativelanguage.googleapis.com/v1beta/models/{urllib.parse.quote(model,safe="")}:generateContent'
    payload={'contents':contents,'generationConfig':{'maxOutputTokens':int(max_tokens)}}
    if system_instruction:
        payload['systemInstruction']={'parts':[{'text':str(system_instruction)}]}
    req=urllib.request.Request(url,data=json.dumps(payload).encode('utf-8'),method='POST',headers={
        'Content-Type':'application/json','x-goog-api-key':api_key,
        'User-Agent':'TIGER-3D-AI/1.6.0'})
    try:
        data=_gemini_request(req)
    except urllib.error.HTTPError as e:
        body=e.read().decode('utf-8','ignore')
        raise RuntimeError(f'Gemini GenerateContent HTTP {e.code}: {_gemini_error_message(body)[:1800]}')
    except Exception as e:
        raise RuntimeError(f'Falha GenerateContent: {e}')
    return _gemini_output_text(data), None


def gemini_api_call(api_key, model, contents, temperature=0.25, max_tokens=1200, previous_interaction_id=None, system_instruction=None):
    """Gemini Turbo: Interactions atual + fallback automático para GenerateContent."""
    if not api_key:
        raise RuntimeError('Informe uma chave Gemini ou defina GEMINI_API_KEY no Windows.')

    # A API Interactions atual usa v1beta (não v1beta2). O formato multimodal abaixo
    # segue o exemplo REST oficial do Google.
    url='https://generativelanguage.googleapis.com/v1beta/interactions'
    input_items=[]
    for item in contents:
        for part in item.get('parts',[]):
            if 'text' in part:
                input_items.append({'type':'text','text':str(part['text'])})
            elif 'inline_data' in part:
                d=part['inline_data']
                input_items.append({'type':'image','data':d['data'],'mime_type':d['mime_type']})

    payload={'model':model,'input':input_items,'store':True,
             'generation_config':{'max_output_tokens':int(max_tokens),'thinking_level':'low'}}
    if previous_interaction_id:
        payload['previous_interaction_id']=previous_interaction_id
    if system_instruction:
        payload['system_instruction']=system_instruction

    req=urllib.request.Request(url,data=json.dumps(payload).encode('utf-8'),method='POST',headers={
        'Content-Type':'application/json','x-goog-api-key':api_key,
        'Api-Revision':'2026-05-20','User-Agent':'TIGER-3D-AI/1.6.0'})
    try:
        data=_gemini_request(req)
        if data.get('status') in ('failed','cancelled'):
            errs=data.get('errors') or []
            msg='; '.join(str(x.get('message','')) for x in errs if isinstance(x,dict)) or 'Interação não concluída.'
            raise RuntimeError(f'Gemini Interactions: {msg}')
        return _gemini_output_text(data), data.get('id'), 'Interactions'
    except urllib.error.HTTPError as e:
        body=e.read().decode('utf-8','ignore')
        # 404/405 normalmente indicam endpoint/modelo indisponível. Tenta a API
        # tradicional automaticamente para manter compatibilidade.
        if e.code not in (404,405):
            raise RuntimeError(f'Gemini Interactions HTTP {e.code}: {_gemini_error_message(body)[:1800]}')
        fallback_contents=[]
        for item in contents:
            parts=[]
            for part in item.get('parts',[]):
                if 'text' in part:
                    parts.append({'text':str(part['text'])})
                elif 'inline_data' in part:
                    d=part['inline_data']
                    parts.append({'inlineData':{'mimeType':d['mime_type'],'data':d['data']}})
            if parts:
                fallback_contents.append({'role':item.get('role','user'),'parts':parts})
        text, iid=_gemini_generate_content(api_key,model,fallback_contents,max_tokens,system_instruction)
        return text, iid, 'GenerateContent fallback'
    except Exception as e:
        if isinstance(e,RuntimeError): raise
        raise RuntimeError(f'Falha de conexão com Gemini: {e}')


def image_part(path):
    p=Path(path); mime={'jpg':'image/jpeg','jpeg':'image/jpeg','png':'image/png','webp':'image/webp'}.get(p.suffix.lower().lstrip('.'),'image/png')
    raw=p.read_bytes()
    # O Google limita dados inline; comprime imagens grandes sem alterar o arquivo original.
    if len(raw) > 8*1024*1024:
        try:
            from io import BytesIO
            im=Image.open(p).convert('RGB')
            im.thumbnail((2200,2200),Image.Resampling.LANCZOS)
            buf=BytesIO(); im.save(buf,format='JPEG',quality=88,optimize=True)
            raw=buf.getvalue(); mime='image/jpeg'
        except Exception:
            pass
    return {'inline_data': {'mime_type':mime,'data':base64.b64encode(raw).decode('ascii')}}

class GeminiThread(QThread):
    done=Signal(str); fail=Signal(str)
    def __init__(self,api_key,model,prompt,image_paths=None,temperature=0.25,max_tokens=1200,previous_interaction_id=None,system_instruction=None):
        super().__init__(); self.api_key=api_key; self.model=model; self.prompt=prompt; self.image_paths=image_paths or []; self.temperature=temperature; self.max_tokens=max_tokens; self.previous_interaction_id=previous_interaction_id; self.system_instruction=system_instruction
    def run(self):
        try:
            parts=[{'text':self.prompt}]
            for p in self.image_paths:
                if p and Path(p).exists(): parts.append(image_part(p))
            text, interaction_id, transport=gemini_api_call(self.api_key,self.model,[{'role':'user','parts':parts}],self.temperature,self.max_tokens,self.previous_interaction_id,self.system_instruction)
            self.done.emit(text+'\n\n[TIGER_INTERACTION_ID:'+str(interaction_id or '')+']\n[TIGER_TRANSPORT:'+str(transport)+']')
        except Exception: self.fail.emit(traceback.format_exc())

class GenerateThread(QThread):
    done=Signal(str); fail=Signal(str); log=Signal(str)
    def __init__(self,image,outdir,res,remove_bg=True,enhance=True,square=True):
        super().__init__(); self.image=image; self.outdir=outdir; self.res=res; self.remove_bg=remove_bg; self.enhance=enhance; self.square=square
    def run(self):
        try:
            runpy=TRIPOSR/'run.py'
            if not runpy.exists():
                raise RuntimeError('Motor TripoSR não encontrado. Execute INSTALAR_IA_TRIPOSR_CPU.bat.')
            job=Path(self.outdir)/('geracao_'+time.strftime('%Y%m%d_%H%M%S')); job.mkdir(parents=True,exist_ok=True)
            image=self.image
            if self.remove_bg:
                prepared=job/'imagem_preparada.png'
                self.log.emit('Preparando imagem e removendo fundo...')
                image=preprocess_image(self.image,prepared,remove_bg=self.remove_bg,enhance=self.enhance,square=self.square)
                if image==self.image:self.log.emit('Remoção de fundo indisponível; usando imagem original.')
                else:self.log.emit('Fundo removido e imagem recortada.')
            cmd=[sys.executable,str(runpy),image,'--output-dir',str(job),'--device','cpu','--chunk-size','512','--mc-resolution',str(self.res)]
            self.log.emit(f'Iniciando TripoSR em CPU — resolução {self.res}...')
            p=subprocess.run(cmd,cwd=str(TRIPOSR),capture_output=True,text=True)
            if p.stdout:self.log.emit(p.stdout[-6000:])
            if p.returncode!=0: raise RuntimeError((p.stderr or p.stdout or 'TripoSR terminou com erro.')[-12000:])
            cs=[]
            for e in ('*.obj','*.glb','*.ply','*.stl'): cs += list(job.rglob(e))
            if not cs: raise RuntimeError('A IA terminou, mas nenhum modelo foi encontrado.')
            self.done.emit(str(max(cs,key=lambda p:p.stat().st_mtime)))
        except Exception:
            self.fail.emit(traceback.format_exc())


class Tiger3D(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f'🐯 {APP} — {VERSION}')
        self.resize(1540,920)
        self.mesh=None; self.file_path=None; self.image_path=None; self.thread=None
        self.bed_x=220.0; self.bed_y=220.0; self.bed_z=250.0
        self.grid_visible=False; self.axes_visible=True; self.shadow_enabled=False; self.pbr_enabled=True; self.smooth_enabled=True; self.bg_mode='Estúdio'; self.camera_perspective=True
        self.light_key=1.35; self.light_fill=0.55; self.light_rim=0.80; self.detail_boost=1.15; self.render_mode='Realista'; self._lights=[]
        self._undo_mesh=None; self._undo_label=''; self._orientation_results=[]; self._overhang_mode=False; self._gemini_prev_id=None
        self.setAcceptDrops(True)
        central=QWidget(); self.setCentralWidget(central); root=QHBoxLayout(central)
        self.setStyleSheet('''
            QGroupBox { font-weight: 700; margin-top: 10px; padding-top: 12px; border: 1px solid #394555; border-radius: 8px; }
            QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 5px; }
            QPushButton { min-height: 30px; padding: 4px 8px; border-radius: 6px; }
            QPushButton:hover { background: #2d3a4b; }
            QComboBox, QDoubleSpinBox, QSpinBox { min-height: 28px; }
            QTabBar::tab { padding: 8px 12px; }
            QTextEdit, QLabel { border-radius: 6px; }
        ''')
        split=QSplitter(Qt.Horizontal); root.addWidget(split)

        vb=QFrame(); vl=QVBoxLayout(vb); vl.setContentsMargins(0,0,0,0)
        self.plotter=QtInteractor(vb); self.plotter.set_background('#0b1018', top='#202a38')
        vl.addWidget(self.plotter.interactor); split.addWidget(vb)

        side=QWidget(); side.setMinimumWidth(500); side.setMaximumWidth(620); sl=QVBoxLayout(side)
        title=QLabel('🐯 TIGER 3D AI'); title.setStyleSheet('font-size:28px;font-weight:800;padding:4px;'); sl.addWidget(title)
        sl.addWidget(QLabel(f'{VERSION} • Studio profissional + IA local'))
        tabs=QTabWidget(); sl.addWidget(tabs,1); split.addWidget(side); split.setSizes([1040,560])

        # Studio
        studio=QWidget(); ml=QVBoxLayout(studio)
        b=QPushButton('📂 ABRIR MODELO'); b.clicked.connect(self.open_model); ml.addWidget(b)
        self.info=QLabel('Nenhum modelo carregado.'); self.info.setWordWrap(True); self.info.setStyleSheet('padding:12px;background:#1b222e;border-radius:10px;'); ml.addWidget(self.info)

        g=QGroupBox('Transformação'); f=QFormLayout(g)
        self.scale=QDoubleSpinBox(); self.scale.setRange(.001,1000); self.scale.setDecimals(4); self.scale.setValue(1); f.addRow('Fator de escala:',self.scale)
        z=QPushButton('Aplicar escala'); z.clicked.connect(self.apply_scale); f.addRow(z)
        self.target=QDoubleSpinBox(); self.target.setRange(.1,10000); self.target.setDecimals(2); self.target.setValue(100); f.addRow('Maior dimensão (mm):',self.target)
        z=QPushButton('📏 Ajustar maior dimensão'); z.clicked.connect(self.fit_target); f.addRow(z)
        self.axis=QComboBox(); self.axis.addItems(['X','Y','Z']); f.addRow('Eixo:',self.axis)
        self.angle=QDoubleSpinBox(); self.angle.setRange(-360,360); self.angle.setValue(90); f.addRow('Ângulo:',self.angle)
        z=QPushButton('↻ Rotacionar'); z.clicked.connect(self.rotate); f.addRow(z)
        ml.addWidget(g)

        dg=QGroupBox('Dimensões e impressão'); df=QFormLayout(dg)
        self.dx=QDoubleSpinBox(); self.dy=QDoubleSpinBox(); self.dz=QDoubleSpinBox()
        for s in (self.dx,self.dy,self.dz): s.setRange(.01,10000); s.setDecimals(2); s.setValue(100)
        df.addRow('X alvo (mm):',self.dx); df.addRow('Y alvo (mm):',self.dy); df.addRow('Z alvo (mm):',self.dz)
        z=QPushButton('📐 Aplicar X/Y/Z'); z.clicked.connect(self.fit_xyz); df.addRow(z)
        z=QPushButton('⬇️ Apoiar na base (Z=0)'); z.clicked.connect(self.drop_to_bed); df.addRow(z)
        ml.addWidget(dg)

        vg=QGroupBox('Visualização profissional'); vf=QFormLayout(vg)
        self.view_color=QComboBox(); self.view_color.addItems(['Cinza metálico','Laranja TIGER','Azul','Verde','Branco','Original da malha']); self.view_color.currentTextChanged.connect(lambda _=None:self.show_mesh()); vf.addRow('Cor:',self.view_color)
        self.material=QComboBox(); self.material.addItems(['Metal','Plástico','Resina','Fosco','Brilhante']); self.material.currentTextChanged.connect(lambda _=None:self.show_mesh()); vf.addRow('Material:',self.material)
        self.edges=QComboBox(); self.edges.addItems(['Sem arestas','Arestas discretas','Malha completa']); self.edges.currentTextChanged.connect(lambda _=None:self.show_mesh()); vf.addRow('Arestas:',self.edges)
        self.background=QComboBox(); self.background.addItems(['Estúdio','Grafite','Claro','Preto']); self.background.currentTextChanged.connect(self.change_background); vf.addRow('Ambiente:',self.background)
        self.show_floor=QCheckBox('Grade de referência'); self.show_floor.stateChanged.connect(self.toggle_grid); vf.addRow(self.show_floor)
        self.shadows=QCheckBox('Sombras realistas'); self.shadows.stateChanged.connect(self.toggle_shadows); vf.addRow(self.shadows)
        self.smooth=QCheckBox('Suavização de superfície'); self.smooth.setChecked(True); self.smooth.stateChanged.connect(self.toggle_smooth); vf.addRow(self.smooth)
        self.pbr=QCheckBox('Material PBR'); self.pbr.setChecked(True); self.pbr.stateChanged.connect(self.toggle_pbr); vf.addRow(self.pbr)
        self.render_mode=QComboBox(); self.render_mode.addItems(['Realista','Detalhado','Inspeção','Impressão 3D']); self.render_mode.currentTextChanged.connect(self.apply_render_mode); vf.addRow('Modo:',self.render_mode)
        self.detail_slider=QSlider(Qt.Horizontal); self.detail_slider.setRange(50,200); self.detail_slider.setValue(115); self.detail_slider.valueChanged.connect(self._detail_changed); vf.addRow('Realce de detalhes:',self.detail_slider)
        self.light_slider=QSlider(Qt.Horizontal); self.light_slider.setRange(20,200); self.light_slider.setValue(135); self.light_slider.valueChanged.connect(self._light_changed); vf.addRow('Luz principal:',self.light_slider)
        self.fill_slider=QSlider(Qt.Horizontal); self.fill_slider.setRange(0,150); self.fill_slider.setValue(55); self.fill_slider.valueChanged.connect(self._fill_changed); vf.addRow('Luz de preenchimento:',self.fill_slider)
        self.rim_slider=QSlider(Qt.Horizontal); self.rim_slider.setRange(0,180); self.rim_slider.setValue(80); self.rim_slider.valueChanged.connect(self._rim_changed); vf.addRow('Luz de recorte:',self.rim_slider)
        ml.addWidget(vg)
        cam=QGroupBox('Câmera'); cf=QHBoxLayout(cam)
        for tx,fn in [('Frente',self.view_front),('Trás',self.view_back),('Topo',self.view_top),('Direita',self.view_right),('Esquerda',self.view_left),('Iso',self.view_iso)]:
            z=QPushButton(tx); z.clicked.connect(fn); cf.addWidget(z)
        ml.addWidget(cam)
        for tx,fn in [('✨ REALÇAR DETALHES',lambda:self._detail_changed(min(200,int(self.detail_slider.value()+20)))),('🧹 REPARAR MALHA',self.repair),('🎯 CENTRALIZAR',self.center),('🪞 ESPELHAR X',self.mirror),('🧭 VISTA ISOMÉTRICA',self.view_iso),('↺ RESETAR CÂMERA',self.reset_camera)]:
            z=QPushButton(tx); z.clicked.connect(fn); ml.addWidget(z)
        z=QPushButton('💾 EXPORTAR'); z.clicked.connect(self.export); ml.addWidget(z); ml.addStretch(); studio_scroll=QScrollArea(); studio_scroll.setWidgetResizable(True); studio_scroll.setFrameShape(QFrame.NoFrame); studio_scroll.setWidget(studio); tabs.addTab(studio_scroll,'Studio')

        # AI / Imagem → 3D
        ai=QWidget(); al=QVBoxLayout(ai); al.addWidget(QLabel('<b>🖼️ IMAGEM → 3D PRO</b>'))
        self.img=QLabel('Arraste uma imagem para cá ou selecione abaixo'); self.img.setAlignment(Qt.AlignCenter); self.img.setMinimumHeight(190); self.img.setStyleSheet('background:#1b222e;border-radius:10px;'); al.addWidget(self.img)
        z=QPushButton('📷 SELECIONAR IMAGEM'); z.clicked.connect(self.choose_image); al.addWidget(z)
        mode_box=QGroupBox('✨ CRIAR 3D — presets profissionais'); mf=QFormLayout(mode_box)
        self.image_mode=QComboBox(); self.image_mode.addItems(['Boneco personalizado','Chaveiro','Medalhão','Relevo','Busto','Miniatura']); self.image_mode.currentTextChanged.connect(self._image_mode_changed); mf.addRow('Produto:',self.image_mode)
        self.creation_style=QComboBox(); self.creation_style.addItems(['Realista','Cartoon','Chibi','Estátua']); mf.addRow('Estilo:',self.creation_style)
        self.creation_height=QDoubleSpinBox(); self.creation_height.setRange(20,300); self.creation_height.setDecimals(0); self.creation_height.setValue(100); self.creation_height.setSuffix(' mm'); mf.addRow('Altura:',self.creation_height)
        self.base_on=QCheckBox('🧱 Adicionar base automaticamente'); self.base_on.setChecked(True); mf.addRow(self.base_on)
        self.base_d=QDoubleSpinBox(); self.base_d.setRange(20,180); self.base_d.setDecimals(1); self.base_d.setValue(60); self.base_d.setSuffix(' mm'); mf.addRow('Diâmetro da base:',self.base_d)
        self.base_h=QDoubleSpinBox(); self.base_h.setRange(2,20); self.base_h.setDecimals(1); self.base_h.setValue(5); self.base_h.setSuffix(' mm'); mf.addRow('Altura da base:',self.base_h)
        self.auto_upright=QCheckBox('🧍 Colocar figura em pé automaticamente'); self.auto_upright.setChecked(True); mf.addRow(self.auto_upright)
        self.auto_quality=QCheckBox('🔬 Verificação técnica automática após gerar'); self.auto_quality.setChecked(True); mf.addRow(self.auto_quality)
        self.keyring_on=QCheckBox('🔑 Aro do chaveiro'); self.keyring_on.setChecked(True); mf.addRow(self.keyring_on)
        self.keyring_d=QDoubleSpinBox(); self.keyring_d.setRange(5,25); self.keyring_d.setDecimals(1); self.keyring_d.setValue(10); self.keyring_d.setSuffix(' mm'); mf.addRow('Diâmetro do aro:',self.keyring_d)
        self.keyring_th=QDoubleSpinBox(); self.keyring_th.setRange(1,8); self.keyring_th.setDecimals(1); self.keyring_th.setValue(3); self.keyring_th.setSuffix(' mm'); mf.addRow('Espessura do aro:',self.keyring_th)
        self.remove_bg=QCheckBox('✨ Remover fundo automaticamente'); self.remove_bg.setChecked(True); mf.addRow(self.remove_bg)
        self.enhance_image=QCheckBox('🔎 Melhorar contraste e nitidez'); self.enhance_image.setChecked(True); mf.addRow(self.enhance_image)
        self.square_image=QCheckBox('⬜ Centralizar em quadro quadrado'); self.square_image.setChecked(True); mf.addRow(self.square_image)
        self.relief_invert=QCheckBox('↕️ Inverter altura do relevo'); self.relief_invert.setChecked(False); mf.addRow(self.relief_invert)
        self.relief_base=QDoubleSpinBox(); self.relief_base.setRange(0.5,20); self.relief_base.setDecimals(1); self.relief_base.setValue(2.5); self.relief_base.setSuffix(' mm'); mf.addRow('Base do relevo:',self.relief_base)
        self.relief_depth=QDoubleSpinBox(); self.relief_depth.setRange(0.5,30); self.relief_depth.setDecimals(1); self.relief_depth.setValue(5.0); self.relief_depth.setSuffix(' mm'); mf.addRow('Altura do relevo:',self.relief_depth)
        self.relief_res=QComboBox(); self.relief_res.addItems(['Rápido — 128','Equilibrado — 192','Detalhado — 256']); self.relief_res.setCurrentIndex(1); mf.addRow('Resolução do relevo:',self.relief_res)
        al.addWidget(mode_box)
        self.gpu=QLabel('GPU: verificando...'); self.gpu.setWordWrap(True); self.gpu.setStyleSheet('padding:9px;background:#1b222e;border-radius:8px;'); al.addWidget(self.gpu)
        self.ai_status=QLabel('Motor: verificando...'); self.ai_status.setWordWrap(True); al.addWidget(self.ai_status)
        self.resolution=QComboBox(); self.resolution.addItems(['Rápido — 96','Equilibrado — 128','Detalhado — 160']); self.resolution.setCurrentIndex(1); al.addWidget(self.resolution)
        z=QPushButton('🧪 PRÉ-VISUALIZAR IMAGEM PREPARADA'); z.clicked.connect(self.preview_prepared); al.addWidget(z)
        z=QPushButton('⚙️ INSTALAR / VERIFICAR MOTOR IA'); z.clicked.connect(self.install_hint); al.addWidget(z)
        z=QPushButton('🤖 GERAR MODELO 3D'); z.setMinimumHeight(46); z.clicked.connect(self.generate); al.addWidget(z)
        z=QPushButton('🧠 VERIFICAÇÃO IA 3D'); z.clicked.connect(self.run_quality_check); al.addWidget(z)
        self.quality_box=QTextEdit(); self.quality_box.setReadOnly(True); self.quality_box.setMaximumHeight(220); self.quality_box.setPlaceholderText('A verificação técnica analisará malha, apoio, componentes, dimensões e base.'); al.addWidget(self.quality_box)
        assist=QGroupBox('🤖 ASSISTENTE TIGER AI — entendimento do pedido'); af=QVBoxLayout(assist)
        self.command_box=QTextEdit(); self.command_box.setPlaceholderText('Ex.: Faça um boneco de 10 cm, base de 6 cm e escreva Anjinho na base.'); self.command_box.setMaximumHeight(80); af.addWidget(self.command_box)
        bz=QPushButton('🧠 INTERPRETAR PEDIDO'); bz.clicked.connect(self.interpret_command); af.addWidget(bz)
        self.command_result=QLabel('A IA local poderá entender comandos simples. A IA online será adicionada em uma próxima etapa.'); self.command_result.setWordWrap(True); af.addWidget(self.command_result); al.addWidget(assist)
        mv=QGroupBox('📸 MULTI-VISTA — preparação para IA avançada'); mfv=QFormLayout(mv)
        self.extra_view_labels=[]
        for label in ('Lado esquerdo','Lado direito','Trás'):
            row=QHBoxLayout(); lab=QLabel('Não selecionada'); row.addWidget(lab,1); btv=QPushButton('Adicionar'); btv.clicked.connect(lambda _,L=label,W=lab:self.choose_extra_view(L,W)); row.addWidget(btv); mfv.addRow(label+':',row); self.extra_view_labels.append((label,lab))
        self.multiview_note=QLabel('As vistas adicionais serão armazenadas no projeto e usadas pela IA avançada quando disponível. A geração local atual continua usando a foto principal.')
        self.multiview_note.setWordWrap(True); mfv.addRow(self.multiview_note); al.addWidget(mv)
        self.progress=QProgressBar(); self.progress.setRange(0,0); self.progress.hide(); al.addWidget(self.progress)
        self._image_mode_changed(self.image_mode.currentText())
        self.ai_log=QTextEdit(); self.ai_log.setReadOnly(True); self.ai_log.setMaximumHeight(190); al.addWidget(self.ai_log); al.addStretch(); ai_scroll=QScrollArea(); ai_scroll.setWidgetResizable(True); ai_scroll.setFrameShape(QFrame.NoFrame); ai_scroll.setWidget(ai); tabs.addTab(ai_scroll,'Imagem → 3D')

        # Tools
        tools=QWidget(); tl=QVBoxLayout(tools); tl.addWidget(QLabel('<b>🛠️ FERRAMENTAS PROFISSIONAIS</b>'))
        for tx,fn in [('🧹 Limpar e reparar',self.repair),('🎯 Centralizar na origem',self.center),('⬇️ Apoiar na base',self.drop_to_bed),('📏 Ajustar para 100 mm',lambda:self.set_target_and_fit(100)),('📏 Ajustar para 150 mm',lambda:self.set_target_and_fit(150)),('📏 Ajustar para 200 mm',lambda:self.set_target_and_fit(200)),('🔻 Otimizar — 50% das faces',lambda:self.optimize(0.50)),('🔻 Otimizar — 25% das faces',lambda:self.optimize(0.25))]:
            z=QPushButton(tx); z.clicked.connect(fn); tl.addWidget(z)
        cut=QGroupBox('Corte por plano Z'); cf=QFormLayout(cut); self.cut_z=QDoubleSpinBox(); self.cut_z.setRange(-10000,10000); self.cut_z.setDecimals(2); self.cut_z.setValue(50); cf.addRow('Altura Z (mm):',self.cut_z); z=QPushButton('✂️ Cortar abaixo de Z'); z.clicked.connect(self.cut_below_z); cf.addRow(z); tl.addWidget(cut)
        self.tool_status=QLabel('Pronto.'); self.tool_status.setWordWrap(True); self.tool_status.setStyleSheet('padding:10px;background:#1b222e;border-radius:8px;'); tl.addWidget(self.tool_status); tl.addStretch(); tools_scroll=QScrollArea(); tools_scroll.setWidgetResizable(True); tools_scroll.setFrameShape(QFrame.NoFrame); tools_scroll.setWidget(tools); tabs.addTab(tools_scroll,'Ferramentas')

        # Preparador profissional
        prep=QWidget(); pl=QVBoxLayout(prep); pl.addWidget(QLabel('<b>🖨️ PREPARADOR 3D PROFISSIONAL</b>'))
        bed=QGroupBox('Mesa de impressão (configurável)'); bf=QFormLayout(bed)
        self.bedx=QDoubleSpinBox(); self.bedy=QDoubleSpinBox(); self.bedz=QDoubleSpinBox()
        for box,val in ((self.bedx,self.bed_x),(self.bedy,self.bed_y),(self.bedz,self.bed_z)):
            box.setRange(10,2000); box.setDecimals(1); box.setValue(val)
        bf.addRow('Mesa X (mm):',self.bedx); bf.addRow('Mesa Y (mm):',self.bedy); bf.addRow('Altura Z (mm):',self.bedz)
        z=QPushButton('📐 Verificar se cabe na mesa'); z.clicked.connect(self.check_bed); bf.addRow(z)
        z=QPushButton('🎯 Centralizar e apoiar'); z.clicked.connect(self.center_and_drop); bf.addRow(z)
        pl.addWidget(bed)
        ana=QGroupBox('Análise e correção'); af=QVBoxLayout(ana)
        for tx,fn in [('🧠 Verificação IA 3D',self.run_quality_check),('🔎 Analisar malha',self.analyze_mesh),('🧹 Reparo seguro',self.repair_safe),('🧰 Reparo completo (tentar fechar furos)',self.repair_full),('🧩 Analisar componentes separados',self.analyze_components)]:
            z=QPushButton(tx); z.clicked.connect(fn); af.addWidget(z)
        self.analysis_box=QTextEdit(); self.analysis_box.setReadOnly(True); self.analysis_box.setMaximumHeight(190); af.addWidget(self.analysis_box)
        pl.addWidget(ana)

        ori=QGroupBox('Orientação inteligente v1.0'); of=QFormLayout(ori)
        self.orientation_profile=QComboBox(); self.orientation_profile.addItems(['Conservador','Menos suporte','Mais estabilidade','Menor altura','Detalhes delicados']); of.addRow('Perfil:',self.orientation_profile)
        self.overhang_angle=QDoubleSpinBox(); self.overhang_angle.setRange(25,70); self.overhang_angle.setDecimals(0); self.overhang_angle.setValue(45); self.overhang_angle.setSuffix('°'); of.addRow('Ângulo de suporte:',self.overhang_angle)
        self.orientation_depth=QComboBox(); self.orientation_depth.addItems(['Rápida — 25 candidatos','Completa — 49 candidatos']); of.addRow('Análise:',self.orientation_depth)
        z=QPushButton('🧠 ANALISAR ORIENTAÇÕES'); z.clicked.connect(self.analyze_orientations); of.addRow(z)
        z=QPushButton('✅ APLICAR ORIENTAÇÃO RECOMENDADA'); z.clicked.connect(self.apply_recommended_orientation); of.addRow(z)
        z=QPushButton('🌡️ MAPA DE OVERHANG'); z.clicked.connect(self.show_overhang_map); of.addRow(z)
        z=QPushButton('↩️ DESFAZER ÚLTIMA ALTERAÇÃO'); z.clicked.connect(self.undo_last); of.addRow(z)
        self.show_bed=QCheckBox('Mostrar mesa no Studio'); self.show_bed.setChecked(False); self.show_bed.stateChanged.connect(lambda *_: self.show_mesh() if self.mesh is not None else None); of.addRow(self.show_bed)
        self.orientation_box=QTextEdit(); self.orientation_box.setReadOnly(True); self.orientation_box.setMaximumHeight(220); self.orientation_box.setPlaceholderText('A análise mostrará as melhores orientações, suporte estimado, contato, altura e estabilidade.'); of.addRow(self.orientation_box)
        pl.addWidget(ori)
        quality=QGroupBox('Qualidade e otimização'); qf=QFormLayout(quality)
        self.decimate=QComboBox(); self.decimate.addItems(['Sem redução','Leve — 75%','Equilibrada — 50%','Forte — 25%']); qf.addRow('Redução:',self.decimate)
        z=QPushButton('🔻 Aplicar redução'); z.clicked.connect(self.optimize_selected); qf.addRow(z)
        z=QPushButton('💾 Exportar STL para impressão'); z.clicked.connect(self.export_stl_quick); qf.addRow(z)
        pl.addWidget(quality); pl.addStretch(); prep_scroll=QScrollArea(); prep_scroll.setWidgetResizable(True); prep_scroll.setFrameShape(QFrame.NoFrame); prep_scroll.setWidget(prep); tabs.addTab(prep_scroll,'Preparar 3D')

        online=QWidget(); ol=QVBoxLayout(online); ol.addWidget(QLabel('<b>☁️ IA ONLINE — GEMINI INTEGRADO AO TIGER</b>'))
        self.online_provider=QComboBox(); self.online_provider.addItems(['Google Gemini','Desativada','OpenAI (futuro)','Endpoint compatível (futuro)']); ol.addWidget(self.online_provider)
        self.online_model=QComboBox(); self.online_model.addItems(['gemini-3.5-flash-lite','gemini-3.5-flash','gemini-3.6-flash','gemini-3.7-flash','gemini-3.8-flash']); ol.addWidget(self.online_model)
        kr=QHBoxLayout(); self.online_key=QLineEdit(); self.online_key.setPlaceholderText('Chave Gemini — ou use GEMINI_API_KEY no Windows'); self.online_key.setEchoMode(QLineEdit.Password); kr.addWidget(self.online_key,1)
        kb=QPushButton('🔑 Carregar'); kb.clicked.connect(self.load_gemini_key); kr.addWidget(kb); sb=QPushButton('💾 Salvar local'); sb.clicked.connect(self.save_gemini_key); kr.addWidget(sb); ol.addLayout(kr)
        self.online_status=QLabel('Gemini: aguardando chave.'); self.online_status.setWordWrap(True); self.online_status.setStyleSheet('padding:9px;background:#1b222e;border-radius:8px;'); ol.addWidget(self.online_status)
        br=QHBoxLayout(); tb=QPushButton('🔌 TESTAR CONEXÃO'); tb.clicked.connect(self.test_online); br.addWidget(tb); ab=QPushButton('📸 ANALISAR IMAGEM ATUAL'); ab.clicked.connect(self.online_analyze_image); br.addWidget(ab); cb=QPushButton('🧹 NOVA CONVERSA'); cb.clicked.connect(self.reset_gemini_conversation); br.addWidget(cb); ol.addLayout(br)
        self.online_chat=QTextEdit(); self.online_chat.setPlaceholderText('A IA poderá explicar o que entendeu da foto, sugerir melhorias e interagir com o projeto.'); self.online_chat.setReadOnly(True); ol.addWidget(self.online_chat)
        self.online_prompt=QLineEdit(); self.online_prompt.setPlaceholderText('Ex.: Faça um boneco de 10 cm, base 60 mm e escreva ANJINHO.'); self.online_prompt.returnPressed.connect(self.online_send); ol.addWidget(self.online_prompt)
        br=QHBoxLayout(); ob=QPushButton('☁️ ENVIAR'); ob.clicked.connect(self.online_send); br.addWidget(ob); ib=QPushButton('🧠 INTERPRETAR + APLICAR AO PROJETO'); ib.clicked.connect(self.online_interpret_apply); br.addWidget(ib); ol.addLayout(br)
        self.online_auto_image=QCheckBox('Enviar a foto atual junto quando eu conversar com a IA'); self.online_auto_image.setChecked(True); ol.addWidget(self.online_auto_image)
        ol.addWidget(QLabel('💡 A versão gratuita do Gemini tem limites de uso. A chave fica local no seu PC; nunca coloque a chave dentro do ZIP ou do código.'))
        tabs.addTab(online,'IA Online')

        sy=QWidget(); dl=QVBoxLayout(sy)
        dl.addWidget(QLabel('<b>🔄 ATUALIZAÇÕES DO TIGER</b>'))
        upd=QGroupBox('Atualizador automático'); uf=QFormLayout(upd)
        self.update_url=QLineEdit(); self.update_url.setText(str(_update_config().get('manifest_url') or '')); self.update_url.setPlaceholderText('URL do update.json (GitHub, servidor ou hospedagem própria)'); uf.addRow('Fonte:',self.update_url)
        ur=QHBoxLayout(); z=QPushButton('💾 Salvar fonte'); z.clicked.connect(self.save_update_config); ur.addWidget(z); z=QPushButton('🔎 VERIFICAR AGORA'); z.clicked.connect(self.check_updates); ur.addWidget(z); z=QPushButton('🔄 ATUALIZAR TIGER'); z.clicked.connect(self.start_update); ur.addWidget(z); uf.addRow(ur)
        self.update_status=QLabel('Atualizador pronto. Suas configurações, modelos e projetos serão preservados.'); self.update_status.setWordWrap(True); uf.addRow(self.update_status)
        dl.addWidget(upd)
        dl.addWidget(QLabel('<b>🔧 DIAGNÓSTICO</b>')); self.diag=QTextEdit(); self.diag.setReadOnly(True); dl.addWidget(self.diag); z=QPushButton('🔄 ATUALIZAR DIAGNÓSTICO'); z.clicked.connect(self.diagnose); dl.addWidget(z); tabs.addTab(sy,'Sistema')
        self.setStatusBar(QStatusBar()); self.statusBar().showMessage(f'{APP} {VERSION} pronto')
        self.load_gemini_key()
        self.diagnose()
        self._setup_scene()
        if _update_config().get('check_on_startup', True):
            QTimer.singleShot(2500, lambda: _schedule_update_check(self))

    def _setup_scene(self):
        try:
            self.plotter.add_axes(interactive=True, line_width=2)
        except Exception:
            try:self.plotter.add_axes()
            except Exception:pass
        self.change_background(self.background.currentText() if hasattr(self,'background') else 'Estúdio')
        try:self.plotter.enable_anti_aliasing()
        except Exception:pass
        try:self.plotter.ren_win.SetMultiSamples(4)
        except Exception:pass
        self._rebuild_lights()

    def dragEnterEvent(self,e):
        if e.mimeData().hasUrls(): e.acceptProposedAction()
    def dropEvent(self,e):
        for u in e.mimeData().urls():
            p=u.toLocalFile()
            if p.lower().endswith(('.stl','.obj','.ply','.off','.3mf')): self.load_path(p); break
            if p.lower().endswith(('.png','.jpg','.jpeg','.webp')): self.set_image(p); break

    def check_bed(self):
        if self.mesh is None:
            self.analysis_box.setPlainText('Carregue um modelo primeiro.'); return
        s=self.mesh.extents
        fits=bool(s[0] <= self.bedx.value()+1e-6 and s[1] <= self.bedy.value()+1e-6 and s[2] <= self.bedz.value()+1e-6)
        txt=(f'Dimensões do modelo: X {s[0]:.2f} × Y {s[1]:.2f} × Z {s[2]:.2f} mm\n'
             f'Mesa configurada: X {self.bedx.value():.1f} × Y {self.bedy.value():.1f} × Z {self.bedz.value():.1f} mm\n\n'
             + ('✅ O modelo cabe na mesa.' if fits else '⚠️ O modelo ultrapassa a mesa em uma ou mais dimensões.'))
        self.analysis_box.setPlainText(txt); self.tool_status.setText('Verificação da mesa concluída.')

    def center_and_drop(self):
        if self.mesh is None:return
        self.center(); self.drop_to_bed(); self.check_bed()

    def analyze_mesh(self):
        if self.mesh is None:
            self.analysis_box.setPlainText('Carregue um modelo primeiro.'); return
        m=self.mesh
        s=m.extents
        parts=[]
        try: comps=m.split(only_watertight=False); parts_count=len(comps)
        except Exception: parts_count=1
        try: boundary=int(len(m.edges_unique)-len(m.edges_sorted_unique)) if hasattr(m,'edges_unique') else -1
        except Exception: boundary=-1
        try: volume=float(m.volume)
        except Exception: volume=float('nan')
        lines=[f'Arquivo: {Path(self.file_path).name if self.file_path else "sem arquivo"}',f'Vértices: {len(m.vertices):,}',f'Faces: {len(m.faces):,}',f'Dimensões: {s[0]:.2f} × {s[1]:.2f} × {s[2]:.2f}',f'Watertight: {"SIM" if m.is_watertight else "NÃO"}',f'Componentes: {parts_count}',f'Volume: {volume:.3f} unidades³']
        if boundary >= 0: lines.append(f'Indicador de bordas: {boundary}')
        lines.append('Sugestão: ' + ('reparo seguro' if not m.is_watertight else 'malha fechada; pode seguir para orientação/escala.'))
        self._last_analysis='\n'.join(lines); self.analysis_box.setPlainText(self._last_analysis)

    def repair_safe(self):
        if self.mesh is None:return
        try:
            self._save_undo('reparo seguro')
            before=(len(self.mesh.vertices),len(self.mesh.faces))
            for n in ('remove_duplicate_faces','remove_degenerate_faces'):
                fn=getattr(self.mesh,n,None)
                if callable(fn):
                    try: fn()
                    except Exception: pass
            self.mesh.remove_unreferenced_vertices()
            try:self.mesh.merge_vertices()
            except Exception:pass
            try:self.mesh.fix_normals()
            except Exception:pass
            after=(len(self.mesh.vertices),len(self.mesh.faces)); self.refresh(f'Reparo seguro: {before[1]:,} → {after[1]:,} faces.')
            self.analyze_mesh()
        except Exception as e: QMessageBox.critical(self,'Reparo seguro',str(e))

    def repair_full(self):
        if self.mesh is None:return
        if len(self.mesh.faces)>300000:
            QMessageBox.information(self,'Reparo completo','Para modelos muito pesados, use primeiro o Reparo seguro. O fechamento automático de furos foi limitado para evitar travamentos.')
            return
        try:
            self.repair_safe()
            try:
                from trimesh import repair
                repair.fill_holes(self.mesh)
                self.mesh.fix_normals()
            except Exception: pass
            self.refresh('Reparo completo concluído.')
            self.analyze_mesh()
        except Exception as e: QMessageBox.warning(self,'Reparo completo',str(e))

    def analyze_components(self):
        if self.mesh is None:return
        try:
            comps=self.mesh.split(only_watertight=False)
            comps=sorted(comps,key=lambda x: len(x.faces),reverse=True)
            text=f'Componentes encontrados: {len(comps)}\n\n'
            for i,c in enumerate(comps[:12],1):
                text += f'{i:02d}. faces {len(c.faces):,} | dimensões {c.extents[0]:.2f} × {c.extents[1]:.2f} × {c.extents[2]:.2f}\n'
            if len(comps)>12:text += f'... e mais {len(comps)-12} componentes.'
            self.analysis_box.setPlainText(text)
        except Exception as e:self.analysis_box.setPlainText('Não foi possível separar os componentes: '+str(e))

    def _save_undo(self, label='alteração'):
        if self.mesh is None:return
        try:
            self._undo_mesh=self.mesh.copy(); self._undo_label=label
        except Exception:
            self._undo_mesh=None; self._undo_label=''

    def undo_last(self):
        if self._undo_mesh is None:
            QMessageBox.information(self,'Desfazer','Ainda não há uma alteração salva para desfazer.'); return
        current=self.mesh
        self.mesh=self._undo_mesh
        self._undo_mesh=current
        label=self._undo_label or 'alteração'
        self.refresh('Desfeito: '+label+'.')
        self.orientation_box.append('\n↩️ Alteração desfeita: '+label)

    def _orientation_candidates(self):
        complete='Completa' in self.orientation_depth.currentText()
        vals=[-45,-30,-15,0,15,30,45] if complete else [-45,-30,0,30,45]
        candidates=[]
        for ax in vals:
            for ay in vals:
                candidates.append((ax,ay,0))
        # Inclui orientações cardinais para peças que realmente precisam deitar.
        candidates += [(90,0,0),(-90,0,0),(0,90,0),(0,-90,0)]
        # Remove duplicados preservando ordem e limita o modo rápido.
        out=[]; seen=set()
        for c in candidates:
            if c not in seen: seen.add(c); out.append(c)
        return out[:49] if complete else out[:25]

    def _orientation_weights(self):
        name=self.orientation_profile.currentText()
        return {
            'Conservador':(0.34,0.28,0.10,0.28),
            'Menos suporte':(0.58,0.20,0.12,0.10),
            'Mais estabilidade':(0.24,0.52,0.10,0.14),
            'Menor altura':(0.24,0.16,0.48,0.12),
            'Detalhes delicados':(0.30,0.18,0.07,0.45),
        }.get(name,(0.34,0.28,0.10,0.28))

    def _rotation_matrix_xyz(self, ax, ay, az=0.0):
        rx=trimesh.transformations.rotation_matrix(np.deg2rad(ax),[1,0,0])[:3,:3]
        ry=trimesh.transformations.rotation_matrix(np.deg2rad(ay),[0,1,0])[:3,:3]
        rz=trimesh.transformations.rotation_matrix(np.deg2rad(az),[0,0,1])[:3,:3]
        return rz @ ry @ rx

    def analyze_orientations(self):
        if self.mesh is None:
            self.orientation_box.setPlainText('Carregue um modelo primeiro.'); return
        try:
            m=self.mesh
            faces=np.asarray(m.faces)
            verts=np.asarray(m.vertices,dtype=float)
            normals=np.asarray(m.face_normals,dtype=float)
            areas=np.asarray(m.area_faces,dtype=float)
            centroids=np.asarray(m.triangles_center,dtype=float)
            # Amostragem determinística mantém análise rápida mesmo com milhões de faces.
            maxf=60000
            if len(faces)>maxf:
                idx=np.linspace(0,len(faces)-1,maxf,dtype=np.int64)
                normals_s=normals[idx]; areas_s=areas[idx]; cents_s=centroids[idx]
            else:
                normals_s=normals; areas_s=areas; cents_s=centroids
            maxv=30000
            if len(verts)>maxv:
                vidx=np.linspace(0,len(verts)-1,maxv,dtype=np.int64); verts_s=verts[vidx]
            else: verts_s=verts
            total_area=max(float(np.sum(areas_s)),1e-9)
            angle=float(self.overhang_angle.value())
            threshold=-math.cos(math.radians(angle))
            bx,by,bz=float(self.bedx.value()),float(self.bedy.value()),float(self.bedz.value())
            rows=[]
            for ax,ay,az in self._orientation_candidates():
                R=self._rotation_matrix_xyz(ax,ay,az)
                rn=normals_s @ R.T
                rc=cents_s @ R.T
                rv=verts_s @ R.T
                mn=rv.min(axis=0); mx=rv.max(axis=0); ext=mx-mn
                # Suporte: faces voltadas significativamente para baixo.
                over=rn[:,2] < threshold
                support=float(np.sum(areas_s[over])/total_area)
                h=max(float(ext[2]),1e-6)
                tol=max(0.35,h*0.004)
                # Contato: faces inferiores quase horizontais e próximas da base.
                contact_mask=(rn[:,2] < -0.82) & (rc[:,2] <= float(mn[2])+tol)
                contact=float(np.sum(areas_s[contact_mask])/total_area)
                # Penaliza inclinação para preservar detalhes delicados em esculturas.
                tilt=min(1.0,(abs(ax)+abs(ay))/180.0)
                fits=bool(ext[0] <= bx+1e-6 and ext[1] <= by+1e-6 and ext[2] <= bz+1e-6)
                rows.append({'angles':(ax,ay,az),'support':support,'contact':contact,'height':h,'tilt':tilt,'fits':fits,'extents':ext})
            heights=np.array([r['height'] for r in rows],dtype=float)
            hmin,hmax=float(heights.min()),float(heights.max())
            contacts=np.array([r['contact'] for r in rows],dtype=float)
            cmax=max(float(contacts.max()),1e-9)
            ws,wc,wh,wt=self._orientation_weights()
            for r in rows:
                hn=(r['height']-hmin)/max(hmax-hmin,1e-9)
                cn=min(1.0,r['contact']/cmax)
                score=ws*r['support'] + wc*(1.0-cn) + wh*hn + wt*r['tilt']
                if not r['fits']: score += 5.0
                r['score']=float(score)
            rows.sort(key=lambda x:x['score'])
            self._orientation_results=rows
            lines=[f'🧠 Perfil: {self.orientation_profile.currentText()} | suporte a partir de {angle:.0f}°',
                   f'Candidatos avaliados: {len(rows)} | mesa: {bx:.0f}×{by:.0f}×{bz:.0f} mm','',
                   'TOP 5 ORIENTAÇÕES (menor pontuação = melhor):']
            for i,r in enumerate(rows[:5],1):
                ax,ay,az=r['angles']; ex=r['extents']
                lines.append(f'{i}. X {ax:+.0f}°  Y {ay:+.0f}° | suporte {r["support"]*100:5.1f}% | contato {r["contact"]*100:5.2f}% | altura {r["height"]:6.1f} mm | {"cabe" if r["fits"] else "NÃO CABE"}')
            best=rows[0]
            lines += ['',f'✅ Recomendada: X {best["angles"][0]:+.0f}° / Y {best["angles"][1]:+.0f}°',
                      f'Estimativa: suporte {best["support"]*100:.1f}% • altura {best["height"]:.1f} mm • contato {best["contact"]*100:.2f}%.',
                      'A análise é geométrica; o fatiador continua sendo a referência final para suportes e tempo de impressão.']
            self.orientation_box.setPlainText('\n'.join(lines))
            self.statusBar().showMessage('Análise inteligente de orientação concluída.')
        except Exception as e:
            self.orientation_box.setPlainText('Erro na análise de orientação:\n'+traceback.format_exc())
            QMessageBox.warning(self,'Orientação inteligente',str(e))

    def apply_recommended_orientation(self):
        if self.mesh is None:return
        if not self._orientation_results:self.analyze_orientations()
        if not self._orientation_results:return
        best=self._orientation_results[0]; ax,ay,az=best['angles']
        try:
            self._save_undo('orientação inteligente')
            c=np.asarray(self.mesh.centroid,dtype=float)
            for deg,axis in ((ax,[1,0,0]),(ay,[0,1,0]),(az,[0,0,1])):
                if abs(deg)>1e-9:
                    self.mesh.apply_transform(trimesh.transformations.rotation_matrix(np.deg2rad(deg),axis,point=c))
            # Centraliza em XY e apoia em Z=0.
            b=self.mesh.bounds; center_xy=((b[0][0]+b[1][0])/2,(b[0][1]+b[1][1])/2)
            self.mesh.apply_translation([-center_xy[0],-center_xy[1],-float(b[0][2])])
            self.refresh(f'Orientação inteligente aplicada: X {ax:+.0f}°, Y {ay:+.0f}°.')
            self.check_bed()
            self.orientation_box.append(f'\n✅ Aplicada: X {ax:+.0f}° / Y {ay:+.0f}°. Use ↩️ para desfazer.')
        except Exception as e:QMessageBox.warning(self,'Aplicar orientação',str(e))

    def auto_orient(self):
        # Compatibilidade com versões anteriores: agora usa o motor inteligente.
        self.analyze_orientations(); self.apply_recommended_orientation()

    def show_overhang_map(self):
        if self.mesh is None:return
        try:
            self._overhang_mode=True
            self.plotter.clear()
            faces=np.hstack([np.full((len(self.mesh.faces),1),3,dtype=np.int64),self.mesh.faces.astype(np.int64)]).ravel()
            poly=pv.PolyData(self.mesh.vertices,faces)
            n=np.asarray(self.mesh.face_normals,dtype=float)
            angle=float(self.overhang_angle.value()); threshold=-math.cos(math.radians(angle))
            vals=np.where(n[:,2] < threshold,1.0,0.0)
            poly.cell_data['Suporte estimado']=vals
            self.change_background('Estúdio',render=False)
            self.plotter.add_mesh(poly,scalars='Suporte estimado',clim=[0,1],cmap='coolwarm',show_edges=False,smooth_shading=True,scalar_bar_args={'title':'Overhang'})
            if hasattr(self,'show_bed') and self.show_bed.isChecked(): self._add_bed_preview()
            try:self.plotter.add_axes(interactive=True,line_width=2)
            except Exception:pass
            self.plotter.reset_camera(); self.plotter.render()
            self.orientation_box.append('\n🌡️ Mapa exibido: regiões quentes indicam faces com maior necessidade estimada de suporte.')
        except Exception as e:QMessageBox.warning(self,'Mapa de overhang',str(e))

    def optimize_selected(self):
        choice=self.decimate.currentText()
        ratio={'Leve — 75%':0.75,'Equilibrada — 50%':0.50,'Forte — 25%':0.25}.get(choice)
        if ratio is None:
            self.tool_status.setText('Nenhuma redução selecionada.'); return
        self.optimize(ratio)
        self.analyze_mesh()

    def export_stl_quick(self):
        if self.mesh is None:return
        p,_=QFileDialog.getSaveFileName(self,'Exportar STL para impressão','tiger_modelo_impressao.stl','STL (*.stl)')
        if not p:return
        try:
            self.mesh.export(p,file_type='stl'); self.statusBar().showMessage('STL exportado: '+p); self.tool_status.setText('STL pronto para fatiamento: '+p)
        except Exception as e: QMessageBox.critical(self,'Exportar STL',str(e))

    def _gemini_system_instruction(self):
        return """Você é o TIGER AI, assistente de projeto integrado ao software TIGER 3D AI. Você não deve responder como um chatbot genérico. Seu trabalho é ajudar o usuário a transformar imagens e comandos em configurações para modelos 3D imprimíveis. Você pode analisar imagens, explicar limitações e orientar o projeto. Quando o usuário pedir um boneco, busto, miniatura, chaveiro, medalhão ou relevo, interprete as medidas e requisitos do pedido. Não diga que não pode gerar arquivos físicos apenas porque você é uma IA: o software TIGER possui um motor 3D local que executará a geração depois que você orientar/aplicar os parâmetros. Para o botão ENVIAR, converse de forma prática e relacionada ao projeto atual. Para o botão INTERPRETAR + APLICAR AO PROJETO, siga rigorosamente o formato JSON solicitado pelo aplicativo. Nunca invente medidas que o usuário não pediu; diferencie mm de cm e confirme a interpretação quando houver ambiguidade."""

    def _gemini_api_key(self):
        return (self.online_key.text().strip() or os.getenv('GEMINI_API_KEY','').strip() or _gemini_key_from_config())

    def load_gemini_key(self):
        key=os.getenv('GEMINI_API_KEY','').strip() or _gemini_key_from_config()
        if key: self.online_key.setText(key); self.online_status.setText('Gemini: chave carregada. Pronto para testar.')
        else: self.online_status.setText('Nenhuma chave encontrada. Crie uma chave no Google AI Studio ou defina GEMINI_API_KEY.')

    def save_gemini_key(self):
        key=self.online_key.text().strip()
        if not key: QMessageBox.information(self,'Gemini','Digite a chave antes de salvar.'); return
        try:
            GEMINI_CONFIG_DIR.mkdir(parents=True,exist_ok=True); GEMINI_CONFIG_FILE.write_text(json.dumps({'api_key':key},ensure_ascii=False),encoding='utf-8')
            self.online_status.setText('Gemini: chave salva localmente no PC.')
        except Exception as e: QMessageBox.warning(self,'Gemini',str(e))

    def _online_images(self):
        paths=[]
        if self.image_path and Path(self.image_path).exists(): paths.append(self.image_path)
        if hasattr(self,'extra_view_labels'):
            for _,lab in self.extra_view_labels:
                p=lab.toolTip()
                if p and Path(p).exists(): paths.append(p)
        return list(dict.fromkeys(paths))[:4]

    def _start_gemini(self,prompt,images=None,temperature=0.25,max_tokens=1200,tag='IA'):
        key=self._gemini_api_key()
        if not key: QMessageBox.information(self,'Gemini','Informe a chave Gemini na aba IA Online ou configure GEMINI_API_KEY no Windows.'); return False
        if hasattr(self,'online_thread') and self.online_thread.isRunning(): QMessageBox.information(self,'Gemini','Já existe uma solicitação de IA em andamento.'); return False
        self.online_status.setText('Gemini: processando...'); self.online_chat.append(f'\n👤 Você: {prompt}')
        self.online_thread=GeminiThread(key,self.online_model.currentText(),prompt,images or [],temperature,max_tokens,getattr(self,'_gemini_prev_id',None),self._gemini_system_instruction())
        self.online_thread.done.connect(lambda t:self._gemini_done(t,tag)); self.online_thread.fail.connect(self._gemini_fail); self.online_thread.start(); return True

    def _gemini_done(self,text,tag='IA'):
        m=re.search(r'\n\n\[TIGER_INTERACTION_ID:([^\]]*)\]',text)
        if m: self._gemini_prev_id=m.group(1) or None
        text=re.sub(r'\n\[TIGER_TRANSPORT:[^\]]+\]\s*$', '', text).rstrip()
        self.online_status.setText('Gemini: resposta recebida.'); self.online_chat.append(f'\n🤖 TIGER AI ({tag}):\n{text}'); self._last_gemini_text=text

    def _gemini_fail(self,msg):
        self.online_status.setText('Gemini: erro de conexão/API.'); self.online_chat.append('\n❌ '+msg[-5000:])

    def reset_gemini_conversation(self):
        self._gemini_prev_id=None
        self.online_chat.append('\n🧹 Nova conversa iniciada. O contexto anterior foi descartado.')
        self.online_status.setText('Gemini: nova conversa pronta.')

    def test_online(self): self._start_gemini('Responda apenas: CONEXÃO TIGER AI OK. Você é o assistente integrado ao programa TIGER 3D AI.',[],0.1,80,'teste')

    def online_analyze_image(self):
        imgs=self._online_images()
        if not imgs: QMessageBox.information(self,'Gemini','Primeiro carregue uma imagem na aba Imagem → 3D.'); return
        prompt="""Você é o especialista de visão do TIGER 3D AI. Analise as imagens anexadas para criação de um boneco 3D imprimível. Descreva objetivamente: pessoa/objeto principal, pose, orientação, rosto, cabelo, roupa, acessórios, partes ocultas, elementos importantes, risco de reconstrução com uma única vista e quais vistas adicionais ajudariam. Não invente detalhes que não aparecem. Termine com uma recomendação prática para gerar um modelo 3D de alta fidelidade."""
        self._start_gemini(prompt,imgs,0.2,1200,'análise visual')

    def online_send(self):
        prompt=self.online_prompt.text().strip()
        if not prompt:return
        imgs=self._online_images() if self.online_auto_image.isChecked() else []; self.online_prompt.clear(); self._start_gemini(prompt,imgs,0.35,1200,'chat')

    def online_interpret_apply(self):
        prompt=self.online_prompt.text().strip()
        if not prompt: QMessageBox.information(self,'TIGER AI','Escreva o que deseja fazer, por exemplo: “boneco 10 cm, base 60 mm, estilo realista”.'); return
        schema="""Responda SOMENTE com JSON válido, sem markdown, usando estas chaves quando existirem: mode (Boneco personalizado|Busto|Miniatura|Chaveiro|Medalhão|Relevo), height (mm), base_d (mm), base_h (mm), base_on (true/false), style (Realista|Cartoon|Chibi|Estátua), name (texto da base). Exemplo: {\"mode\":\"Boneco personalizado\",\"height\":100,\"base_d\":60,\"base_h\":5,\"base_on\":true,\"style\":\"Realista\",\"name\":\"Anjinho\"}. Interprete o pedido do usuário e não invente valores que não foram pedidos."""
        imgs=self._online_images() if self.online_auto_image.isChecked() else []; self.online_prompt.clear(); key=self._gemini_api_key()
        if not key: QMessageBox.information(self,'Gemini','Informe a chave Gemini primeiro.'); return
        self.online_status.setText('Gemini: interpretando e preparando o projeto...'); self.online_chat.append(f'\n👤 Você: {prompt}')
        self.online_thread=GeminiThread(key,self.online_model.currentText(),schema+'\nPEDIDO:\n'+prompt,imgs,0.1,500,None,self._gemini_system_instruction())
        self.online_thread.done.connect(self._apply_gemini_command); self.online_thread.fail.connect(self._gemini_fail); self.online_thread.start()

    def _apply_gemini_command(self,text):
        m=re.search(r'\n\n\[TIGER_INTERACTION_ID:([^\]]*)\]',text)
        if m: self._gemini_prev_id=m.group(1) or None
        text=re.sub(r'\n\[TIGER_TRANSPORT:[^\]]+\]\s*$', '', text).rstrip()
        self.online_chat.append('\n🤖 TIGER AI: '+text); raw=text.strip().replace('```json','').replace('```','').strip()
        try: cfg=json.loads(raw)
        except Exception: self.online_status.setText('Gemini respondeu, mas não retornou JSON válido.'); return
        try:
            if cfg.get('mode'): self.image_mode.setCurrentText(cfg['mode'])
            if cfg.get('height') is not None: self.creation_height.setValue(float(cfg['height']))
            if cfg.get('base_d') is not None: self.base_d.setValue(float(cfg['base_d']))
            if cfg.get('base_h') is not None: self.base_h.setValue(float(cfg['base_h']))
            if cfg.get('base_on') is not None: self.base_on.setChecked(bool(cfg['base_on']))
            if cfg.get('style'): self.creation_style.setCurrentText(cfg['style'])
            self.online_status.setText('Gemini: configuração aplicada ao projeto. Revise e clique em GERAR MODELO 3D.')
            self.online_chat.append('✅ Configuração aplicada ao TIGER 3D AI.'); self.ai_log.append('☁️ Gemini aplicou configuração: '+json.dumps(cfg,ensure_ascii=False))
        except Exception as e: self.online_status.setText('Gemini: não foi possível aplicar tudo: '+str(e))

    def save_update_config(self):
        try:
            cfg=_update_config(); cfg['manifest_url']=self.update_url.text().strip(); UPDATE_CONFIG_FILE.write_text(json.dumps(cfg,ensure_ascii=False,indent=2),encoding='utf-8')
            self.update_status.setText('Fonte de atualização salva. Clique em VERIFICAR AGORA para consultar a versão disponível.')
        except Exception as e:
            QMessageBox.warning(self,'Atualizações',str(e))

    def check_updates(self):
        try:
            self.save_update_config()
            cfg=_update_config(); url=str(cfg.get('manifest_url') or '').strip()
            if not url or 'SEU_USUARIO' in url:
                self.update_status.setText('Configure primeiro a URL do update.json. O TIGER já está preparado para atualizar sem reinstalar dependências, modelos ou projetos.')
                return
            _launch_updater(check_only=True)
            self.update_status.setText('Verificação iniciada. Se houver nova versão, o atualizador informará e poderá baixar a atualização.')
        except Exception as e:
            QMessageBox.warning(self,'Atualizações',str(e))

    def start_update(self):
        try:
            self.save_update_config()
            cfg=_update_config(); url=str(cfg.get('manifest_url') or '').strip()
            if not url or 'SEU_USUARIO' in url:
                self.update_status.setText('Configure a URL do update.json antes de atualizar.')
                return
            r=QMessageBox.question(self,'Atualizar TIGER',f'Atualizar o TIGER a partir da fonte configurada?\n\nA atualização preservará API key, modelos, projetos e a pasta output_ai.',QMessageBox.Yes|QMessageBox.No)
            if r!=QMessageBox.Yes: return
            _launch_updater(check_only=False)
            QMessageBox.information(self,'Atualizador','O atualizador foi aberto. O TIGER será fechado para aplicar a atualização e poderá ser reaberto automaticamente.')
            self.close()
        except Exception as e:
            QMessageBox.warning(self,'Atualizações',str(e))

    def diagnose(self):
        lines=[f'Aplicativo: {APP} {VERSION}',f'Sistema: {platform.platform()}',f'Python: {sys.version.split()[0]}',f'Pasta: {BASE}']
        try: lines += ['NumPy: '+np.__version__,'Trimesh: '+trimesh.__version__,'PyVista: '+pv.__version__]
        except Exception as e: lines.append('Bibliotecas 3D: erro — '+str(e))
        try:
            import torch; lines += ['PyTorch: '+torch.__version__,'CUDA: '+str(torch.cuda.is_available())]
            if torch.cuda.is_available(): lines.append('GPU CUDA: '+torch.cuda.get_device_name(0))
        except Exception: lines.append('PyTorch: não instalado')
        try:
            import onnxruntime; lines.append('ONNX Runtime: '+onnxruntime.__version__)
        except Exception: lines.append('ONNX Runtime: não instalado')
        try: import rembg; lines.append('rembg: disponível')
        except Exception: lines.append('rembg: não instalado')
        try: import PIL; lines.append('Pillow: '+PIL.__version__)
        except Exception: lines.append('Pillow: não instalado')
        lines.append('TripoSR: '+('INSTALADO' if (TRIPOSR/'run.py').exists() else 'não instalado'))
        self.diag.setPlainText('\n'.join(lines))
        gpu='não detectada'
        try:
            r=subprocess.run(['powershell','-NoProfile','-Command','Get-CimInstance Win32_VideoController | Select-Object -ExpandProperty Name'],capture_output=True,text=True,timeout=5)
            ns=[x.strip() for x in r.stdout.splitlines() if x.strip()]; gpu=' | '.join(ns) if ns else gpu
        except Exception: pass
        self.gpu.setText('GPU: '+gpu+'\nModo recomendado: CPU nesta máquina, salvo acelerador compatível.')
        self.ai_status.setText('Motor TripoSR: INSTALADO • CPU' if (TRIPOSR/'run.py').exists() else 'Motor TripoSR: NÃO INSTALADO')

    def set_image(self,p):
        self.image_path=p; pm=QPixmap(p)
        if not pm.isNull(): self.img.setPixmap(pm.scaled(330,210,Qt.KeepAspectRatio,Qt.SmoothTransformation))
        self.statusBar().showMessage('Imagem selecionada: '+Path(p).name)
    def choose_image(self):
        p,_=QFileDialog.getOpenFileName(self,'Escolher imagem','','Imagens (*.png *.jpg *.jpeg *.webp)')
        if p:self.set_image(p)
    def _image_mode_changed(self, mode):
        relief=(mode=='Relevo')
        keychain=(mode=='Chaveiro')
        medal=(mode=='Medalhão')
        for w in (self.relief_invert,self.relief_base,self.relief_depth,self.relief_res): w.setVisible(relief or medal)
        self.creation_style.setVisible(not relief)
        self.creation_height.setVisible(not relief)
        self.base_on.setVisible(mode in ('Boneco personalizado','Busto','Miniatura','Medalhão'))
        self.base_d.setVisible(mode in ('Boneco personalizado','Busto','Miniatura','Medalhão'))
        self.base_h.setVisible(mode in ('Boneco personalizado','Busto','Miniatura','Medalhão'))
        self.auto_upright.setVisible(mode in ('Boneco personalizado','Busto','Miniatura'))
        self.keyring_on.setVisible(keychain)
        self.keyring_d.setVisible(keychain)
        self.keyring_th.setVisible(keychain)
        self.resolution.setVisible(not relief)
        if relief:
            self.ai_status.setText('Modo local: gera alto-relevo STL sem depender do motor IA.')
        elif keychain:
            self.ai_status.setText('Chaveiro: IA + aro de impressão integrado. O aro é gerado como componente separado.')
        elif medal:
            self.ai_status.setText('Medalhão: IA + disco circular de suporte para impressão.')
        else:
            self.ai_status.setText('Motor TripoSR: INSTALADO • CPU' if (TRIPOSR/'run.py').exists() else 'Motor TripoSR: NÃO INSTALADO')

    def interpret_command(self):
        cfg=interpret_tiger_command(self.command_box.toPlainText())
        if not cfg:
            self.command_result.setText('Não identifiquei parâmetros. Tente: “boneco de 10 cm, base de 6 cm”.'); return
        if 'mode' in cfg: self.image_mode.setCurrentText(cfg['mode'])
        if 'height' in cfg: self.creation_height.setValue(max(self.creation_height.minimum(),min(self.creation_height.maximum(),cfg['height'])))
        if 'base_d' in cfg: self.base_d.setValue(max(self.base_d.minimum(),min(self.base_d.maximum(),cfg['base_d'])))
        if 'base_on' in cfg: self.base_on.setChecked(cfg['base_on'])
        if 'style' in cfg: self.creation_style.setCurrentText(cfg['style'])
        parts=[]
        if 'mode' in cfg: parts.append(cfg['mode'])
        if 'height' in cfg: parts.append(f"{cfg['height']:.0f} mm")
        if 'base_d' in cfg: parts.append(f"base {cfg['base_d']:.0f} mm")
        if 'name' in cfg: parts.append(f"texto “{cfg['name']}” (preparado para a etapa de gravação)")
        self.command_result.setText('Entendi: ' + ' • '.join(parts) + '. Revise os campos e clique em GERAR MODELO 3D.')
        self.ai_log.append('🧠 Comando interpretado localmente: '+str(cfg))

    def choose_extra_view(self,label,widget):
        p,_=QFileDialog.getOpenFileName(self,'Adicionar vista — '+label,'','Imagens (*.png *.jpg *.jpeg *.webp)')
        if p:
            widget.setText(Path(p).name)
            widget.setToolTip(p)
            self.ai_log.append(f'📸 Vista adicional {label}: {p}')

    def preview_prepared(self):
        if not self.image_path:
            QMessageBox.information(self,'Imagem → 3D','Selecione ou arraste uma imagem primeiro.'); return
        try:
            job=OUTPUT/'preview'; job.mkdir(parents=True,exist_ok=True)
            dst=job/'imagem_preparada.png'
            preprocess_image(self.image_path,dst,self.remove_bg.isChecked(),self.enhance_image.isChecked(),self.square_image.isChecked())
            self.set_image(str(dst)); self.ai_log.append('Prévia preparada: '+str(dst)); self.statusBar().showMessage('Imagem preparada para 3D.')
        except Exception as e: QMessageBox.warning(self,'Prévia da imagem',str(e))

    def install_hint(self):
        bat=BASE/'INSTALAR_IA_TRIPOSR_CPU.bat'
        if bat.exists(): QMessageBox.information(self,APP,'Feche o TIGER e execute INSTALAR_IA_TRIPOSR_CPU.bat.\n\nO instalador verifica o ambiente, instala PyTorch CPU e prepara o TripoSR. A primeira instalação precisa de internet.')
        else: QMessageBox.warning(self,APP,'Instalador da IA não encontrado.')
    def generate(self):
        if not self.image_path:
            QMessageBox.information(self,'Criar 3D','Selecione uma imagem primeiro.'); return
        mode=self.image_mode.currentText()
        if mode=='Relevo':
            try:
                job=OUTPUT/('relevo_'+time.strftime('%Y%m%d_%H%M%S')); job.mkdir(parents=True,exist_ok=True)
                res=int(self.relief_res.currentText().split('—')[-1].strip())
                out=job/'relevo_3d.stl'; self.ai_log.clear(); self.ai_log.append('Gerando RELEVO local...')
                image_to_relief(self.image_path,out,resolution=res,base_mm=float(self.relief_base.value()),relief_mm=float(self.relief_depth.value()),invert=self.relief_invert.isChecked())
                self.load_path(str(out)); self.statusBar().showMessage('Relevo 3D criado com sucesso.'); self.ai_log.append('Modelo: '+str(out))
            except Exception: QMessageBox.critical(self,'Erro no relevo',traceback.format_exc())
            return
        if not (TRIPOSR/'run.py').exists():
            QMessageBox.warning(self,'Motor não instalado','Execute INSTALAR_IA_TRIPOSR_CPU.bat primeiro.'); return
        res=int(self.resolution.currentText().split('—')[-1].strip())
        self.progress.show(); self.ai_log.clear()
        self.ai_log.append(f'Produto: {mode} • estilo: {self.creation_style.currentText()}')
        self.ai_log.append('Gerando a malha base com TripoSR em CPU...')
        self.statusBar().showMessage('Gerando 3D localmente...')
        self.thread=GenerateThread(self.image_path,str(OUTPUT),res,self.remove_bg.isChecked(),self.enhance_image.isChecked(),self.square_image.isChecked())
        self.thread.done.connect(lambda p:self.generated_product(p,mode)); self.thread.fail.connect(self.failed); self.thread.log.connect(self.ai_log.append); self.thread.start()
    def generated_product(self,p,mode):
        try:
            raw=mesh_from_file(p)
            # Medalhão usa relevo local da própria imagem; os demais aproveitam a malha IA.
            if mode=='Medalhão':
                job=OUTPUT/('medalhao_'+time.strftime('%Y%m%d_%H%M%S')); job.mkdir(parents=True,exist_ok=True)
                relief=job/'medalhao_relevo.stl'
                image_to_relief(self.image_path,relief,resolution=int(self.relief_res.currentText().split('—')[-1].strip()),base_mm=float(self.relief_base.value()),relief_mm=float(self.relief_depth.value()),invert=self.relief_invert.isChecked())
                raw=mesh_from_file(str(relief))
            final=apply_creation_preset(raw,mode,height_mm=float(self.creation_height.value()),base_on=self.base_on.isChecked(),base_d=float(self.base_d.value()),base_h=float(self.base_h.value()),keyring_on=self.keyring_on.isChecked(),keyring_d=float(self.keyring_d.value()),keyring_thickness=float(self.keyring_th.value()),auto_upright=self.auto_upright.isChecked())
            job=OUTPUT/('produto_'+mode.lower().replace(' ','_')+'_'+time.strftime('%Y%m%d_%H%M%S')); job.mkdir(parents=True,exist_ok=True)
            out=job/(mode.lower().replace(' ','_')+'.stl'); final.export(out,file_type='stl')
            self.progress.hide(); self.load_path(str(out)); self.statusBar().showMessage(f'{mode} criado com sucesso.')
            self.ai_log.append(f'Preset aplicado: {mode}')
            if mode in ('Boneco personalizado','Busto','Miniatura'): self.ai_log.append(f'Base: {"SIM" if self.base_on.isChecked() else "NÃO"} • {self.base_d.value():.1f} mm × {self.base_h.value():.1f} mm')
            if mode=='Chaveiro' and self.keyring_on.isChecked(): self.ai_log.append(f'Aro: {self.keyring_d.value():.1f} mm • espessura {self.keyring_th.value():.1f} mm')
            self.ai_log.append('STL pronto para a etapa Preparar 3D.')
            if self.auto_quality.isChecked():
                self.run_quality_check()
                self.ai_log.append('Verificação técnica automática concluída.')
        except Exception:
            self.progress.hide(); self.failed(traceback.format_exc())

    def run_quality_check(self):
        if self.mesh is None:
            if hasattr(self,'quality_box'): self.quality_box.setPlainText('Gere ou carregue um modelo primeiro.')
            return
        try:
            expected=None; bd=None
            if hasattr(self,'image_mode') and self.image_mode.currentText() in ('Boneco personalizado','Busto','Miniatura'):
                expected=float(self.creation_height.value()) + (float(self.base_h.value()) if self.base_on.isChecked() else 0.0)
                bd=float(self.base_d.value()) if self.base_on.isChecked() else None
            report=mesh_quality_report(self.mesh,expected_height=expected,base_d=bd)
            if hasattr(self,'quality_box'): self.quality_box.setPlainText(report)
            if hasattr(self,'analysis_box'): self.analysis_box.setPlainText(report)
            self.tool_status.setText('Verificação técnica 3D concluída.')
        except Exception as e:
            if hasattr(self,'quality_box'): self.quality_box.setPlainText('Erro na verificação: '+str(e))

    def generated(self,p): self.progress.hide(); self.load_path(p); self.statusBar().showMessage('Modelo 3D gerado com sucesso.'); self.ai_log.append('Modelo: '+p); QMessageBox.information(self,APP,'Modelo 3D gerado com sucesso!\n\nO modelo já foi carregado no Studio.')
    def failed(self,m): self.progress.hide(); self.statusBar().showMessage('Erro durante a geração.'); self.ai_log.append(m[-10000:]); QMessageBox.critical(self,'Erro na IA',m[-10000:])

    def load_path(self,p):
        try:
            m=mesh_from_file(p)
            if len(m.vertices)==0 or len(m.faces)==0: raise RuntimeError('A malha está vazia.')
            self.mesh=m; self.file_path=p; self.update_info(); self.show_mesh(); self._sync_dims(); self.tool_status.setText('Modelo carregado: '+Path(p).name)
        except Exception as e: QMessageBox.critical(self,'Erro ao carregar modelo',str(e))
    def update_info(self):
        if self.mesh is None:return
        s=self.mesh.extents
        peso='pesado' if len(self.mesh.faces)>=500000 else 'normal'
        self.info.setText(f'<b>{Path(self.file_path).name}</b><br>Vértices: {len(self.mesh.vertices):,}<br>Faces: {len(self.mesh.faces):,}<br>Dimensões: {s[0]:.2f} × {s[1]:.2f} × {s[2]:.2f} unidades<br>Watertight: {"SIM" if self.mesh.is_watertight else "NÃO"}<br>Renderização: {peso}')
    def _sync_dims(self):
        if self.mesh is None:return
        s=self.mesh.extents
        for box,val in zip((self.dx,self.dy,self.dz),s): box.setValue(max(0.01,min(10000,float(val))))
        self.cut_z.setValue(max(-10000,min(10000,float(self.mesh.bounds[1][2] if self.mesh else 50))))

    def _model_center_and_scale(self):
        if self.mesh is None:
            return (0,0,0), 1.0
        b=self.mesh.bounds
        c=((b[0][0]+b[1][0])/2,(b[0][1]+b[1][1])/2,(b[0][2]+b[1][2])/2)
        s=max(float(np.max(self.mesh.extents)),1.0)
        return c,s

    def _rebuild_lights(self):
        """Three-point lighting using VTK lights; no extra dependencies."""
        try:
            from vtkmodules.vtkRenderingCore import vtkLight
            for light in list(self._lights):
                try:self.plotter.renderer.RemoveLight(light)
                except Exception:pass
            self._lights=[]
            c,s=self._model_center_and_scale()
            positions=[
                (c[0]-1.7*s,c[1]-1.2*s,c[2]+2.0*s),
                (c[0]+1.6*s,c[1]+0.8*s,c[2]+0.7*s),
                (c[0]+0.2*s,c[1]+1.5*s,c[2]-1.2*s)
            ]
            specs=[
                (self.light_key,(1.0,0.94,0.86)),
                (self.light_fill,(0.78,0.86,1.0)),
                (self.light_rim,(1.0,0.78,0.55))
            ]
            for pos,(inten,col) in zip(positions,specs):
                L=vtkLight(); L.SetLightTypeToSceneLight(); L.SetPosition(*pos); L.SetFocalPoint(*c); L.SetIntensity(float(inten)); L.SetColor(*col); L.SetPositional(True); L.SetConeAngle(80); L.SetExponent(1)
                self.plotter.renderer.AddLight(L); self._lights.append(L)
            self.plotter.renderer.SetLightFollowCamera(False)
        except Exception:
            self._lights=[]

    def _detail_changed(self,v):
        self.detail_boost=max(0.5,float(v)/100.0)
        if self.mesh is not None:self.show_mesh()
    def _light_changed(self,v):
        self.light_key=float(v)/100.0
        if self.mesh is not None:self.show_mesh()
    def _fill_changed(self,v):
        self.light_fill=float(v)/100.0
        if self.mesh is not None:self.show_mesh()
    def _rim_changed(self,v):
        self.light_rim=float(v)/100.0
        if self.mesh is not None:self.show_mesh()

    def apply_render_mode(self,mode):
        self.render_mode=mode
        if mode=='Realista':
            self.edges.setCurrentText('Sem arestas'); self.smooth.setChecked(True); self.pbr.setChecked(True); self.shadows.setChecked(True)
        elif mode=='Detalhado':
            self.edges.setCurrentText('Arestas discretas'); self.smooth.setChecked(True); self.pbr.setChecked(True); self.shadows.setChecked(True)
        elif mode=='Inspeção':
            self.edges.setCurrentText('Arestas discretas'); self.smooth.setChecked(False); self.pbr.setChecked(False); self.shadows.setChecked(False)
        elif mode=='Impressão 3D':
            self.edges.setCurrentText('Sem arestas'); self.smooth.setChecked(True); self.pbr.setChecked(False); self.shadows.setChecked(False)
        if self.mesh is not None:self.show_mesh()

    def _add_bed_preview(self):
        try:
            bx=float(self.bedx.value()) if hasattr(self,'bedx') else self.bed_x
            by=float(self.bedy.value()) if hasattr(self,'bedy') else self.bed_y
            plane=pv.Plane(center=(0,0,-0.25),direction=(0,0,1),i_size=bx,j_size=by,i_resolution=10,j_resolution=10)
            self.plotter.add_mesh(plane,color='#4c6175',opacity=0.16,show_edges=True,edge_color='#70869a',line_width=0.5)
        except Exception:pass

    def show_mesh(self):
        if self.mesh is None:return
        self._overhang_mode=False
        self.plotter.clear()
        try:self.plotter.add_axes(interactive=True, line_width=2)
        except Exception:
            try:self.plotter.add_axes()
            except Exception:pass
        self.change_background(self.background.currentText() if hasattr(self,'background') else 'Estúdio', render=False)
        faces=np.hstack([np.full((len(self.mesh.faces),1),3,dtype=np.int64),self.mesh.faces.astype(np.int64)]).ravel()
        poly=pv.PolyData(self.mesh.vertices,faces)
        palette={'Cinza metálico':'#a7b0bf','Laranja TIGER':'#f28c28','Azul':'#4d8cff','Verde':'#43a047','Branco':'#e8edf5'}
        name=self.view_color.currentText(); color=palette.get(name,'#a7b0bf')
        if name=='Original da malha':
            try:
                fc=np.asarray(self.mesh.visual.face_colors); color=tuple((fc[0,:3]/255).tolist()) if len(fc) else '#a7b0bf'
            except Exception: color='#a7b0bf'
        edge_mode=self.edges.currentText(); heavy=len(self.mesh.faces)>=500000
        if heavy and edge_mode=='Malha completa':
            edge_mode='Arestas discretas'; self.statusBar().showMessage('Modelo pesado: wireframe completo limitado somente na visualização.')
        show_edges=edge_mode!='Sem arestas'; lw=0.16 if edge_mode=='Arestas discretas' else 0.42
        mat=self.material.currentText() if hasattr(self,'material') else 'Metal'
        params={'Metal':(0.12,0.82,0.58,30),'Plástico':(0.10,0.90,0.22,18),'Resina':(0.06,0.78,0.34,35),'Fosco':(0.04,0.62,0.08,10),'Brilhante':(0.08,0.98,0.82,55)}
        ambient,diffuse,specular,specpow=params.get(mat,params['Metal'])
        # Detail boost improves relief readability without changing geometry.
        diffuse=min(1.0,diffuse*self.detail_boost)
        specular=min(1.0,specular*(0.85+0.15*self.detail_boost))
        kwargs=dict(color=color,show_edges=show_edges,edge_color='#202a38',line_width=lw,ambient=ambient,diffuse=diffuse,specular=specular,specular_power=specpow)
        kwargs['smooth_shading']=bool(self.smooth.isChecked()) if hasattr(self,'smooth') else True
        if hasattr(self,'pbr') and self.pbr.isChecked():
            kwargs.update(pbr=True, metallic=0.55 if mat=='Metal' else 0.0, roughness=0.24 if mat=='Brilhante' else (0.38 if mat=='Metal' else 0.58))
        try:
            self.plotter.add_mesh(poly,**kwargs)
        except TypeError:
            for k in ('pbr','metallic','roughness'):
                kwargs.pop(k,None)
            self.plotter.add_mesh(poly,**kwargs)
        self._rebuild_lights()
        if hasattr(self,'show_bed') and self.show_bed.isChecked(): self._add_bed_preview()
        if self.grid_visible:
            try:self.plotter.show_grid(color='#596575',font_size=9,location='outer',ticks='outside')
            except Exception:pass
        if self.shadow_enabled:
            try:self.plotter.enable_shadows()
            except Exception:pass
        self.plotter.reset_camera(); self.plotter.reset_camera_clipping_range(); self.plotter.render()

    def change_background(self,mode,render=True):
        self.bg_mode=mode
        presets={
            'Estúdio':('#0b1018','#202a38'),
            'Grafite':('#121417','#30343b'),
            'Claro':('#e9edf2','#c7ced8'),
            'Preto':('#020305','#0a0c10')
        }
        top,bottom=presets.get(mode,presets['Estúdio'])
        try:self.plotter.set_background(top,top=top if mode=='Preto' else bottom)
        except Exception:
            try:self.plotter.set_background(top)
            except Exception:pass
        if render:self.plotter.render()

    def toggle_shadows(self,*_):
        self.shadow_enabled=self.shadows.isChecked(); self.show_mesh()
    def toggle_smooth(self,*_):
        self.smooth_enabled=self.smooth.isChecked(); self.show_mesh()
    def toggle_pbr(self,*_):
        self.pbr_enabled=self.pbr.isChecked(); self.show_mesh()
    def set_parallel(self,parallel):
        self.camera_perspective=not parallel
        try:self.plotter.enable_parallel_projection() if parallel else self.plotter.disable_parallel_projection()
        except Exception:pass
        self.plotter.render()

    def toggle_grid(self,*_): self.grid_visible=self.show_floor.isChecked(); self.show_mesh()
    def open_model(self):
        p,_=QFileDialog.getOpenFileName(self,'Abrir modelo 3D','','Modelos (*.stl *.obj *.ply *.off *.3mf);;Todos (*.*)')
        if p:self.load_path(p)
    def apply_scale(self):
        if self.mesh is not None:self._save_undo('escala'); self.mesh.apply_scale(float(self.scale.value())); self.scale.setValue(1); self.refresh('Escala aplicada.')
    def fit_target(self):
        if self.mesh is None:return
        mx=float(np.max(self.mesh.extents))
        if mx>0:self._save_undo('ajuste de dimensão'); self.mesh.apply_scale(float(self.target.value())/mx); self.refresh('Maior dimensão ajustada para %.2f mm.'%self.target.value())
    def set_target_and_fit(self,v): self.target.setValue(v); self.fit_target()
    def fit_xyz(self):
        if self.mesh is None:return
        s=self.mesh.extents
        if np.any(np.asarray(s)<=0):return
        factors=np.array([self.dx.value()/s[0],self.dy.value()/s[1],self.dz.value()/s[2]],dtype=float)
        self._save_undo('dimensões X/Y/Z'); self.mesh.apply_scale(factors); self.refresh('Dimensões X/Y/Z aplicadas.')
    def drop_to_bed(self):
        if self.mesh is None:return
        self._save_undo('apoiar na base'); minz=float(self.mesh.bounds[0][2]); self.mesh.apply_translation([0,0,-minz]); self.refresh('Modelo apoiado na base: Z mínimo = 0.')
    def rotate(self):
        if self.mesh is None:return
        self._save_undo('rotação manual'); a=np.deg2rad(float(self.angle.value())); axis={'X':[1,0,0],'Y':[0,1,0],'Z':[0,0,1]}[self.axis.currentText()]; self.mesh.apply_transform(trimesh.transformations.rotation_matrix(a,axis)); self.refresh('Rotação aplicada.')
    def mirror(self):
        if self.mesh is None:return
        self._save_undo('espelhamento X'); self.mesh.apply_scale([-1,1,1]); self.mesh.invert(); self.refresh('Espelhamento X aplicado.')
    def center(self):
        if self.mesh is not None:self._save_undo('centralização'); self.mesh.apply_translation(-self.mesh.centroid); self.refresh('Modelo centralizado na origem.')
    def repair(self):
        if self.mesh is None:return
        try:
            b=(len(self.mesh.vertices),len(self.mesh.faces))
            for n in ('remove_duplicate_faces','remove_degenerate_faces'):
                fn=getattr(self.mesh,n,None)
                if callable(fn):
                    try:fn()
                    except Exception:pass
            self.mesh.remove_unreferenced_vertices()
            try:self.mesh.merge_vertices()
            except Exception:pass
            try:self.mesh.fix_normals()
            except Exception:pass
            a=(len(self.mesh.vertices),len(self.mesh.faces)); self.refresh(f'Reparo concluído. Vértices {b[0]:,}→{a[0]:,}; faces {b[1]:,}→{a[1]:,}.')
        except Exception as e:QMessageBox.critical(self,'Reparo',str(e))
    def optimize(self,ratio):
        if self.mesh is None:return
        before=len(self.mesh.faces); target=max(100,int(before*ratio))
        try:
            fn=getattr(self.mesh,'simplify_quadric_decimation',None)
            if not callable(fn): raise RuntimeError('Otimização avançada não está disponível nesta instalação.')
            try:new=fn(face_count=target)
            except TypeError:new=fn(percent=ratio)
            if new is None: raise RuntimeError('O motor de redução não retornou uma malha.')
            self.mesh=new; self.refresh(f'Otimização concluída: {before:,} → {len(self.mesh.faces):,} faces.')
        except Exception as e:
            QMessageBox.warning(self,'Otimizar malha',str(e)+'\n\nO modelo original foi preservado.')
    def cut_below_z(self):
        if self.mesh is None:return
        try:
            z=float(self.cut_z.value()); plane_origin=[0,0,z]; plane_normal=[0,0,1]
            new=self.mesh.slice_plane(plane_origin=plane_origin,plane_normal=plane_normal,cap=True)
            if new is None or len(new.faces)==0: raise RuntimeError('O corte removeria toda a malha.')
            self.mesh=new; self.refresh(f'Corte aplicado abaixo de Z={z:.2f} mm.')
        except Exception as e: QMessageBox.warning(self,'Corte',str(e))
    def refresh(self,msg=''):
        self.update_info(); self._sync_dims(); self.show_mesh(); self.tool_status.setText(msg or 'Atualizado.'); self.statusBar().showMessage(msg or 'Atualizado.')
    def export(self):
        if self.mesh is None: QMessageBox.information(self,'Exportar','Carregue um modelo primeiro.'); return
        p,_=QFileDialog.getSaveFileName(self,'Salvar modelo','tiger_modelo.stl','STL (*.stl);;OBJ (*.obj);;PLY (*.ply);;GLB (*.glb)')
        if not p:return
        try:
            ext=Path(p).suffix.lower().lstrip('.')
            self.mesh.export(p,file_type=ext); self.statusBar().showMessage('Exportado: '+p); QMessageBox.information(self,'Exportar','Modelo exportado com sucesso.\n\n'+p)
        except Exception as e:QMessageBox.critical(self,'Exportar',str(e))
    def _view(self,method):
        if self.mesh is None:return
        try:
            getattr(self.plotter,method)()
            self.plotter.reset_camera_clipping_range(); self.plotter.render()
        except Exception as e: self.statusBar().showMessage('Câmera: '+str(e))
    def view_front(self): self._view('view_xz')
    def view_back(self):
        if self.mesh is None:return
        try:self.plotter.view_xz(negative=True); self.plotter.reset_camera_clipping_range(); self.plotter.render()
        except Exception:pass
    def view_top(self): self._view('view_xy')
    def view_right(self): self._view('view_yz')
    def view_left(self):
        if self.mesh is None:return
        try:self.plotter.view_yz(negative=True); self.plotter.reset_camera_clipping_range(); self.plotter.render()
        except Exception:pass

    def view_iso(self):
        if self.mesh is None:return
        self.plotter.view_isometric(); self.plotter.reset_camera(); self.plotter.reset_camera_clipping_range(); self.plotter.render()
    def reset_camera(self):
        self.plotter.reset_camera(); self.plotter.reset_camera_clipping_range(); self.plotter.render()
    def closeEvent(self,e):
        try:
            if self.thread and self.thread.isRunning():self.thread.requestInterruption(); self.thread.wait(1000)
            self.plotter.close()
        except Exception:pass
        e.accept()


if __name__=='__main__':
    try:
        app=QApplication(sys.argv); app.setStyle('Fusion'); w=Tiger3D(); w.show(); sys.exit(app.exec())
    except Exception:
        errbox('TIGER 3D AI — erro inesperado',traceback.format_exc()); sys.exit(1)
