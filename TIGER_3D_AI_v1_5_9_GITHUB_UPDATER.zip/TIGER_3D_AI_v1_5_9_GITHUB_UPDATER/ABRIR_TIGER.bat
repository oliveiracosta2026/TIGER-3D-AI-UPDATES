@echo off
cd /d "%~dp0"
title TIGER 3D AI v1.5.8
if not exist ".venv\Scripts\python.exe" (
 echo O TIGER ainda nao foi instalado.
 echo Execute INSTALAR_TIGER_312.bat primeiro.
 pause
 exit /b 1
)
".venv\Scripts\python.exe" main.py
if errorlevel 1 (
 echo.
 echo O TIGER fechou com erro. Use TESTAR_TIGER.bat para diagnostico.
 pause
)
