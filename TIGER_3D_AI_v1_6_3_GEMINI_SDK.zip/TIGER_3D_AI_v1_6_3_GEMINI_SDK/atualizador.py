import argparse, hashlib, json, os, shutil, subprocess, sys, tempfile, time, urllib.request, urllib.error, zipfile
from pathlib import Path

APP_NAME='TIGER 3D AI'
CURRENT_VERSION='v1.6.3'
CONFIG_NAME='update_config.json'
MANIFEST_TIMEOUT=30
EXCLUDE_DIRS={'TripoSR','output_ai','config','.venv','venv','__pycache__','backups'}
EXCLUDE_FILES={'update_config.json','gemini.json'}


def norm(v):
    s=str(v).strip().lower().lstrip('v')
    nums=[]
    for p in s.split('.'):
        m=''.join(c for c in p if c.isdigit())
        nums.append(int(m or 0))
    while len(nums)<4: nums.append(0)
    return tuple(nums[:4])


def load_cfg(app_dir):
    p=Path(app_dir)/CONFIG_NAME
    if not p.exists(): return {}
    try: return json.loads(p.read_text(encoding='utf-8'))
    except Exception: return {}


def fetch_json(url):
    req=urllib.request.Request(url,headers={'User-Agent':'TIGER-3D-AI-Updater/1.0','Accept':'application/json'})
    with urllib.request.urlopen(req,timeout=MANIFEST_TIMEOUT) as r:
        return json.loads(r.read().decode('utf-8'))


def sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()


def download(url,dst):
    req=urllib.request.Request(url,headers={'User-Agent':'TIGER-3D-AI-Updater/1.0'})
    with urllib.request.urlopen(req,timeout=120) as r, open(dst,'wb') as f:
        shutil.copyfileobj(r,f,1024*1024)


def log(msg):
    try: print('[TIGER UPDATE]',msg,flush=True)
    except Exception: pass


def check(app_dir):
    cfg=load_cfg(app_dir); url=str(cfg.get('manifest_url') or '').strip()
    if not url or 'SEU_USUARIO' in url:
        return None,'Fonte de atualização não configurada.'
    manifest=fetch_json(url)
    latest=str(manifest.get('version') or '').strip()
    if not latest: raise RuntimeError('update.json sem campo "version".')
    return manifest, None


def safe_extract(zip_path,tmp):
    with zipfile.ZipFile(zip_path) as z:
        for info in z.infolist():
            name=Path(info.filename)
            if name.is_absolute() or '..' in name.parts: raise RuntimeError('Pacote de atualização inválido.')
        z.extractall(tmp)
    # If package has one top-level folder, use it as root.
    entries=[p for p in Path(tmp).iterdir()]
    if len(entries)==1 and entries[0].is_dir(): return entries[0]
    return Path(tmp)


def backup_app(app_dir,version):
    root=Path(app_dir); b=root/'backups'/version
    if b.exists(): shutil.rmtree(b,ignore_errors=True)
    b.mkdir(parents=True,exist_ok=True)
    for p in root.iterdir():
        if p.name in EXCLUDE_DIRS or p.name in EXCLUDE_FILES or p.name==b.name: continue
        dest=b/p.name
        try:
            if p.is_dir(): shutil.copytree(p,dest,dirs_exist_ok=True)
            else: shutil.copy2(p,dest)
        except Exception: pass
    return b


def apply_zip(app_dir,zip_path,new_version):
    root=Path(app_dir); tmp=Path(tempfile.mkdtemp(prefix='tiger_update_'))
    try:
        src=safe_extract(zip_path,tmp)
        backup_app(root,CURRENT_VERSION)
        for p in src.rglob('*'):
            rel=p.relative_to(src)
            if not rel.parts: continue
            if rel.parts[0] in EXCLUDE_DIRS or rel.name in EXCLUDE_FILES: continue
            dst=root/rel
            if p.is_dir(): dst.mkdir(parents=True,exist_ok=True)
            else:
                dst.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(p,dst)
        (root/'installed_version.json').write_text(json.dumps({'version':new_version},ensure_ascii=False,indent=2),encoding='utf-8')
    finally:
        shutil.rmtree(tmp,ignore_errors=True)


def ensure_optional_dependencies(app_dir):
    """Instala somente o SDK novo necessário, sem reinstalar o ambiente inteiro."""
    venv=Path(app_dir)/'.venv'/'Scripts'/'python.exe'
    py=str(venv if venv.exists() else sys.executable)
    try:
        subprocess.run([py,'-c','import google.genai'],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=15)
        return 'Google GenAI SDK já instalado.'
    except Exception:
        p=subprocess.run([py,'-m','pip','install','--disable-pip-version-check','google-genai','--retries','5','--timeout','120'],capture_output=True,text=True,timeout=300)
        if p.returncode!=0: raise RuntimeError('Não foi possível instalar o Google GenAI SDK. '+(p.stderr or p.stdout or '')[-2500:])
        return 'Google GenAI SDK instalado automaticamente.'

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--app-dir',required=True); ap.add_argument('--check-only',action='store_true'); ap.add_argument('--apply',action='store_true'); ap.add_argument('--package'); args=ap.parse_args()
    app=Path(args.app_dir).resolve()
    try:
        manifest,msg=check(app)
        if msg:
            log(msg); return 0
        latest=str(manifest['version'])
        if norm(latest)<=norm(CURRENT_VERSION):
            log(f'Já está atualizado ({CURRENT_VERSION}).'); return 0
        log(f'Nova versão disponível: {latest}')
        if args.check_only:
            # Optional notification through Windows PowerShell; no dependency on Qt.
            try:
                title='TIGER 3D AI — atualização disponível'
                body=f'Nova versão {latest} disponível. Abra o TIGER e use Sistema > VERIFICAR AGORA.'
                ps=f"Add-Type -AssemblyName PresentationFramework; [System.Windows.MessageBox]::Show('{body.replace("'","''")}','{title}') | Out-Null"
                subprocess.Popen(['powershell','-NoProfile','-ExecutionPolicy','Bypass','-Command',ps],creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            except Exception: pass
            return 0
        url=str(manifest.get('url') or manifest.get('package_url') or '').strip()
        if not url: raise RuntimeError('update.json sem "url" ou "package_url".')
        tmp=Path(tempfile.gettempdir())/'tiger_update.zip';
        if tmp.exists(): tmp.unlink()
        log('Baixando atualização...'); download(url,tmp)
        expected=str(manifest.get('sha256') or '').lower().strip()
        if expected and sha256(tmp).lower()!=expected: raise RuntimeError('SHA-256 da atualização não confere.')
        apply_zip(app,tmp,latest); tmp.unlink(missing_ok=True)
        if norm(latest)>=norm('v1.6.3'):
            log(ensure_optional_dependencies(app))
        log('Atualização aplicada com sucesso.')
        subprocess.Popen(['cmd','/c',str(app/'ABRIR_TIGER.bat')],cwd=str(app),creationflags=getattr(subprocess,'CREATE_NEW_CONSOLE',0))
        return 0
    except Exception as e:
        log('ERRO: '+str(e)); return 1

if __name__=='__main__': sys.exit(main())
