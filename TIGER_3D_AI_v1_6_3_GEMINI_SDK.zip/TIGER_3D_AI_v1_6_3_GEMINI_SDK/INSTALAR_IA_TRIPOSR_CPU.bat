@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title TIGER 3D AI v0.8.0 - Motor IA CPU
if not exist ".venv\Scripts\python.exe" (
 echo Execute INSTALAR_TIGER_312.bat primeiro.
 pause
 exit /b 1
)
call ".venv\Scripts\activate.bat"

echo ==========================================================
echo      TIGER 3D AI v0.8.0 - TRIPOSR CPU
 echo ==========================================================
echo.
python -c "import urllib.request; urllib.request.urlopen('https://pypi.org',timeout=20); print('Internet OK')"
if errorlevel 1 goto FAIL

python -m pip install --upgrade setuptools wheel --retries 8 --timeout 120
if errorlevel 1 goto FAIL
python -m pip install --index-url https://download.pytorch.org/whl/cpu --only-binary=:all: torch torchvision --retries 8 --timeout 120
if errorlevel 1 goto FAIL
python -m pip install --only-binary=:all: onnxruntime==1.22.0 tokenizers==0.15.2 --retries 8 --timeout 120
if errorlevel 1 goto FAIL
python -m pip install "transformers==4.36.2" "omegaconf==2.3.0" "Pillow==10.1.0" "einops==0.7.0" "huggingface-hub" "imageio[ffmpeg]" "rembg" "xatlas==0.0.9" "moderngl==5.10.0" "PyMCubes==0.1.6" --retries 8 --timeout 120
if errorlevel 1 goto FAIL
echo Corrigindo compatibilidade NumPy/SciPy...
python -m pip install --force-reinstall --only-binary=:all: "numpy==1.26.4" "scipy==1.12.0" --retries 8 --timeout 120
if errorlevel 1 goto FAIL

if not exist TripoSR (
 echo Baixando codigo do TripoSR...
 powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -UseBasicParsing 'https://github.com/VAST-AI-Research/TripoSR/archive/refs/heads/main.zip' -OutFile 'triposr.zip'"
 if not exist triposr.zip goto FAIL
 powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Path 'triposr.zip' -DestinationPath '.' -Force"
 if exist TripoSR rmdir /s /q TripoSR
 if exist TripoSR-main move TripoSR-main TripoSR >nul
 del /q triposr.zip
)
if not exist TripoSR\run.py goto FAIL

>TripoSR\torchmcubes.py echo import numpy as np
>>TripoSR\torchmcubes.py echo import torch
>>TripoSR\torchmcubes.py echo import mcubes
>>TripoSR\torchmcubes.py echo def marching_cubes(volume, level=0.0):
>>TripoSR\torchmcubes.py echo     if hasattr(volume, 'detach'): volume=volume.detach().cpu().numpy()
>>TripoSR\torchmcubes.py echo     v,f=mcubes.marching_cubes(np.asarray(volume),level)
>>TripoSR\torchmcubes.py echo     return torch.as_tensor(v,dtype=torch.float32),torch.as_tensor(f,dtype=torch.long)
>>TripoSR\torchmcubes.py echo def sparse_marching_cubes(volume, level=0.0): return marching_cubes(volume,level)

python -c "import numpy,scipy; print('NumPy',numpy.__version__); print('SciPy',scipy.__version__); assert numpy.__version__.startswith('1.26.') and scipy.__version__.startswith('1.12.')"
if errorlevel 1 goto FAIL
python -c "import torch,onnxruntime,rembg,pymatting; print('PyTorch',torch.__version__); print('ONNX Runtime',onnxruntime.__version__); print('rembg OK'); print('pymatting OK')"
if errorlevel 1 goto FAIL
>TRIPOSR_CPU_OK.txt echo INSTALADO=SIM
>>TRIPOSR_CPU_OK.txt echo MODO=CPU
>>TRIPOSR_CPU_OK.txt echo VERSAO=v0.8.0

echo.
echo ==========================================================
echo MOTOR IA INSTALADO COM SUCESSO!
echo Abra o TIGER com ABRIR_TIGER.bat
 echo ==========================================================
pause
exit /b 0

:FAIL
echo.
echo ==========================================================
echo ERRO NA INSTALACAO DA IA.
echo Tire uma foto desta janela e envie aqui.
echo ==========================================================
pause
exit /b 1
