# TIGER 3D AI v1.4.0 CPU

Studio 3D local com IA, otimizado para máquinas que precisam trabalhar em CPU.

## Instalação
1. Extraia o ZIP em uma pasta nova.
2. Execute INSTALAR_TIGER_312.bat.
3. Execute INSTALAR_IA_TRIPOSR_CPU.bat para habilitar Imagem → 3D.
4. Execute ABRIR_TIGER.bat.

A v0.6.0 deve ser mantida como backup.

## Visualização v0.7
Use Studio → Visualização profissional para alternar material, PBR, sombras, suavização, ambiente e arestas. A câmera possui vistas rápidas e a navegação 3D continua disponível pelo mouse.


## Atualização automática
A versão 1.5.6 inclui um atualizador que preserva modelos, projetos e a chave Gemini. Configure a fonte em **Sistema → Atualizações** usando um `update.json` HTTPS.
