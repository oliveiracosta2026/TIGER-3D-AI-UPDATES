@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title TIGER 3D AI v0.7.0 - Corrigir IA CPU
if not exist ".venv\Scripts\python.exe" (
 echo Ambiente .venv nao encontrado.
 echo Execute INSTALAR_TIGER_312.bat primeiro.
 pause
 exit /b 1
)
call ".venv\Scripts\activate.bat"
echo ==========================================================
echo   TIGER 3D AI v0.7.0 - CORRECAO IA CPU
echo ==========================================================
echo.
echo O erro encontrado foi uma incompatibilidade NumPy/SciPy.
echo Instalando versoes compativeis...
echo.
python -m pip install --upgrade pip setuptools wheel --retries 8 --timeout 120
if errorlevel 1 goto FAIL
python -m pip install --force-reinstall --only-binary=:all: "numpy==1.26.4" "scipy==1.12.0" --retries 8 --timeout 120
if errorlevel 1 goto FAIL
python -c "import numpy,scipy; print('NumPy:',numpy.__version__); print('SciPy:',scipy.__version__); assert numpy.__version__.startswith('1.26.') and scipy.__version__.startswith('1.12.')"
if errorlevel 1 goto FAIL
python -c "import pymatting,rembg; print('pymatting OK'); print('rembg OK')"
if errorlevel 1 goto FAIL
>TRIPOSR_CPU_OK.txt echo INSTALADO=SIM
>>TRIPOSR_CPU_OK.txt echo MODO=CPU
>>TRIPOSR_CPU_OK.txt echo VERSAO=v0.7.0
>>TRIPOSR_CPU_OK.txt echo NUMPY=1.26.4
>>TRIPOSR_CPU_OK.txt echo SCIPY=1.12.0
echo.
echo ==========================================================
echo CORRECAO CONCLUIDA COM SUCESSO!
echo Agora abra ABRIR_TIGER.bat
 echo ==========================================================
pause
exit /b 0
:FAIL
echo.
echo ==========================================================
echo A CORRECAO NAO FOI CONCLUIDA.
echo Tire uma foto desta janela e envie aqui.
echo ==========================================================
pause
exit /b 1
