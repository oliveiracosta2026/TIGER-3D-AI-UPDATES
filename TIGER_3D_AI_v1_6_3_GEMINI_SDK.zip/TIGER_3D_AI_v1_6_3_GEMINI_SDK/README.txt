TIGER 3D AI v1.3.0 CPU

INSTALAÇÃO
1. Extraia o ZIP em uma pasta nova.
2. Execute INSTALAR_TIGER_312.bat.
3. Execute INSTALAR_IA_TRIPOSR_CPU.bat se quiser usar Imagem -> 3D.
4. Execute ABRIR_TIGER.bat.

NOVIDADES DA V1.3
- Interface lateral com rolagem: os controles não ficam mais espremidos em telas menores.
- Orientação inteligente com perfis: Conservador, Menos suporte, Mais estabilidade, Menor altura e Detalhes delicados.
- Análise de 25 ou 49 orientações antes de aplicar qualquer rotação.
- Estimativa geométrica de overhang/suporte, contato com a mesa, altura e encaixe na mesa.
- A orientação recomendada NÃO usa mais apenas a menor altura.
- Mapa visual de overhang no Studio.
- Visualização opcional da mesa de impressão.
- Botão Desfazer última alteração para operações principais.
- Mantidos: visual profissional, TripoSR local CPU, reparo, escala, X/Y/Z, corte, redução e exportação STL.

IMPORTANTE
A análise de suporte/orientação é uma estimativa geométrica. O fatiador continua sendo a referência final para suportes, tempo de impressão e material.
As dimensões da mesa são configuráveis e não representam um perfil oficial de impressora específica.
