TIGER 3D AI — ATUALIZADOR AUTOMÁTICO

O programa agora possui uma camada de atualização que preserva:
- chave Gemini em %APPDATA%\TIGER3D_AI
- TripoSR e demais modelos locais
- output_ai e projetos
- configurações da instalação

CONFIGURAÇÃO DA FONTE
1. Crie um update.json em um endereço HTTPS.
2. Coloque a URL desse arquivo em Sistema > Atualizações > Fonte.
3. O update.json deve conter:
   {"version":"v1.5.8","url":"https://.../TIGER_3D_AI_v1_5_7.zip","sha256":"...","notes":"..."}
4. O ZIP deve conter os arquivos do programa, mas não precisa conter TripoSR/output_ai.

Para usar GitHub, a fonte pode ser um raw.githubusercontent.com apontando para update.json.
A URL é configurável no próprio TIGER, portanto não será necessário reinstalar o programa quando a fonte mudar.
