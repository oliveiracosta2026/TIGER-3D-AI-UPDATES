@echo off
setlocal
cd /d "%~dp0"
title TIGER 3D AI - Diagnostico
if not exist ".venv\Scripts\python.exe" (
 echo Ambiente .venv nao encontrado. Execute INSTALAR_TIGER_312.bat.
 pause
 exit /b 1
)
call ".venv\Scripts\activate.bat"
echo ===== TIGER DIAGNOSTICO =====
python --version
python -c "import sys; print('Python OK:',sys.executable)"
python -c "import numpy; print('NumPy OK:',numpy.__version__)" || goto FAIL
python -c "import trimesh; print('Trimesh OK:',trimesh.__version__)" || goto FAIL
python -c "import pyvista; print('PyVista OK:',pyvista.__version__)" || goto FAIL
python -c "import PySide6; print('PySide6 OK:',PySide6.__version__)" || goto FAIL
python -c "import google.genai; print('Google GenAI SDK OK')" || echo Google GenAI SDK nao instalado - use INSTALAR_GEMINI_SDK.bat.
python -c "import pyvistaqt; print('PyVistaQt OK')" || goto FAIL
python -c "import torch; print('PyTorch OK:',torch.__version__)" || echo PyTorch nao instalado - normal para o modo base.
if exist TripoSR\run.py (echo TripoSR OK) else echo TripoSR nao instalado.
echo.
echo DIAGNOSTICO CONCLUIDO.
pause
exit /b 0
:FAIL
echo.
echo FALHA DE DEPENDENCIA.
pause
exit /b 1
