TIGER 3D AI v1.5.2 — GEMINI INTERACTIONS

Correção da integração Gemini:
- usa a Gemini Interactions API atual;
- modelos Gemini 3.5/3.6/3.8;
- análise multimodal de imagens;
- conversa com contexto usando previous_interaction_id;
- instrução de sistema própria do TIGER AI para evitar respostas genéricas;
- mantém a chave somente localmente.

Uso:
1. Abra IA Online.
2. Selecione Google Gemini.
3. Escolha Gemini 3.5 Flash-Lite ou Gemini 3.8 Flash.
4. Use TESTAR CONEXÃO.
5. Para controlar parâmetros do projeto, use INTERPRETAR + APLICAR AO PROJETO.

A geração do STL continua sendo feita pelo motor 3D local do TIGER; o Gemini orienta/analisará o projeto e o aplicativo aplica os parâmetros.
