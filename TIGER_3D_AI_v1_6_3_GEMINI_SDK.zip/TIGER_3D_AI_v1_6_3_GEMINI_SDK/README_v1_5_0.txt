TIGER 3D AI v1.5.0 — CPU + IA ONLINE GEMINI

1) Execute INSTALAR_TIGER_312.bat como nas versões anteriores.
2) Para IA local, mantenha o TripoSR instalado.
3) Para IA online: abra a aba "IA Online", escolha Google Gemini e informe sua chave.
4) Também é possível definir a variável de ambiente GEMINI_API_KEY no Windows.
5) Teste com "TESTAR CONEXÃO".
6) Em "Imagem → 3D", carregue a foto. Na aba IA Online use "ANALISAR IMAGEM ATUAL".
7) Escreva comandos como: "Faça um boneco de 10 cm, base de 60 mm e estilo realista" e use "INTERPRETAR + APLICAR AO PROJETO".

A chave da API é pessoal. Nunca publique a chave, não a coloque dentro do código e não envie o ZIP com sua chave gravada.
