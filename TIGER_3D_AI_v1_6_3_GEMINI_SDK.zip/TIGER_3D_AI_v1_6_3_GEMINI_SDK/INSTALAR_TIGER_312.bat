@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title TIGER 3D AI v1.6.3 - Instalador
color 0B

echo ==========================================================
echo          TIGER 3D AI v1.6.3 - INSTALADOR
echo ==========================================================
echo.
set "PY312="
if exist "%LocalAppData%\Programs\Python\Python312\python.exe" set "PY312=%LocalAppData%\Programs\Python\Python312\python.exe"
if not defined PY312 if exist "%ProgramFiles%\Python312\python.exe" set "PY312=%ProgramFiles%\Python312\python.exe"
if not defined PY312 goto INSTALL_PY

goto PY_OK

:INSTALL_PY
where winget >nul 2>nul
if not errorlevel 1 (
 echo Python 3.12 nao encontrado. Tentando instalar pelo WinGet...
 winget install --id Python.Python.3.12 -e --accept-source-agreements --accept-package-agreements
 if exist "%LocalAppData%\Programs\Python\Python312\python.exe" set "PY312=%LocalAppData%\Programs\Python\Python312\python.exe"
)
if defined PY312 goto PY_OK

echo Baixando Python 3.12.10...
set "PYINSTALLER=%TEMP%\python-3.12.10-amd64.exe"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -UseBasicParsing 'https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe' -OutFile '%PYINSTALLER%'"
if not exist "%PYINSTALLER%" goto FAIL
start /wait "" "%PYINSTALLER%" /quiet InstallAllUsers=0 PrependPath=1 Include_launcher=1 Include_test=0 SimpleInstall=1
if exist "%LocalAppData%\Programs\Python\Python312\python.exe" set "PY312=%LocalAppData%\Programs\Python\Python312\python.exe"
if not defined PY312 goto FAIL

:PY_OK
"%PY312%" -c "import sys; print(sys.version); raise SystemExit(0 if sys.version_info[:2]==(3,12) else 1)"
if errorlevel 1 goto FAIL

echo.
echo Criando ambiente virtual...
if exist ".venv" rmdir /s /q ".venv"
"%PY312%" -m venv .venv
if errorlevel 1 goto FAIL
call ".venv\Scripts\activate.bat"
python -m pip install --upgrade pip setuptools wheel --retries 8 --timeout 120
if errorlevel 1 goto FAIL
pip install -r requirements.txt --retries 8 --timeout 120
if errorlevel 1 goto FAIL
python -c "import numpy,trimesh,pyvista,PySide6,pyvistaqt,PIL; print('BASE OK')"
if errorlevel 1 goto FAIL

echo.
echo ==========================================================
echo TIGER BASE INSTALADO COM SUCESSO!
echo Execute agora ABRIR_TIGER.bat
echo Para instalar a IA, use INSTALAR_IA_TRIPOSR_CPU.bat
 echo ==========================================================
pause
exit /b 0

:FAIL
echo.
echo ==========================================================
echo ERRO NA INSTALACAO DO TIGER.
echo Verifique a internet e envie uma foto desta janela se continuar.
echo ==========================================================
pause
exit /b 1
