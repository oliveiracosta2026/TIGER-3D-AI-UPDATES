TIGER 3D AI v1.5.3

CORREÇÃO DA API GEMINI INTERACTIONS

1. Instale normalmente.
2. Abra IA ONLINE.
3. Selecione Google Gemini.
4. Use sua chave já cadastrada.
5. Clique em TESTAR CONEXÃO.

O erro da v1.5.2:
HTTP 400: The value 'text' is not supported for 'type' at 'input[0]'.

foi corrigido. A API atual espera a entrada do usuário como um UserInputStep contendo os blocos de conteúdo.

Não é necessário criar uma nova chave apenas por causa desta correção.
