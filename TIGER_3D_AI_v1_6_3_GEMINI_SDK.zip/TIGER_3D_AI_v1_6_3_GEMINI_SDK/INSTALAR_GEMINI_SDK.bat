@echo off
setlocal
cd /d "%~dp0"
title TIGER 3D AI - Instalar Google GenAI SDK
if not exist ".venv\Scripts\python.exe" (
 echo Execute INSTALAR_TIGER_312.bat primeiro.
 pause
 exit /b 1
)
call ".venv\Scripts\activate.bat"
python -m pip install --upgrade google-genai --retries 8 --timeout 120
if errorlevel 1 goto FAIL
python -c "import google.genai; print('Google GenAI SDK instalado com sucesso.')"
if errorlevel 1 goto FAIL
echo.
echo Pronto. Abra o TIGER novamente.
pause
exit /b 0
:FAIL
echo Falha ao instalar o Google GenAI SDK.
pause
exit /b 1
