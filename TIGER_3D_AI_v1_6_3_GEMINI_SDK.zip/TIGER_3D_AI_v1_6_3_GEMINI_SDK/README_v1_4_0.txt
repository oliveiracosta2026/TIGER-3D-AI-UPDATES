TIGER 3D AI v1.4.0 CPU

Execute ABRIR_TIGER.bat no Windows.

Novidades: orientação inteligente de figuras, base profissional, assistente de comandos em português, registro de vistas adicionais e painel preparado para IA online.

A geração local continua funcionando com TripoSR CPU. A IA online não é chamada automaticamente e nenhuma chave é necessária para usar a parte local.
