TIGER 3D AI v1.5.4

Esta versão corrige o erro HTTP 400 "user_input is not supported for type at input". A Interactions API atual recebe input como uma lista de blocos Content, por exemplo type=text e type=image.

Use sua mesma chave Gemini. Primeiro clique em TESTAR CONEXÃO.
