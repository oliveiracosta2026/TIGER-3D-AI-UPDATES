@echo off
setlocal
 title TIGER 3D AI - Diagnostico de rede GitHub
 echo ==============================================
 echo TIGER 3D AI v1.6.7 - DIAGNOSTICO DE REDE
 echo ==============================================
 echo.
 echo [1] Testando DNS de github.com...
 nslookup github.com
 echo.
 echo [2] Testando DNS de codeload.github.com...
 nslookup codeload.github.com
 echo.
 echo [3] Testando acesso ao GitHub...
 powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-WebRequest -UseBasicParsing 'https://github.com' -TimeoutSec 20; Write-Host ('GitHub HTTP '+[int]$r.StatusCode) } catch { Write-Host ('GitHub falhou: '+$_.Exception.Message) }"
 echo.
 echo [4] Testando PyPI...
 powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-WebRequest -UseBasicParsing 'https://pypi.org' -TimeoutSec 20; Write-Host ('PyPI HTTP '+[int]$r.StatusCode) } catch { Write-Host ('PyPI falhou: '+$_.Exception.Message) }"
 echo.
 echo Copie/fotografe este resultado e envie no ChatGPT.
 pause
