@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title TIGER 3D AI v1.6.7 - Motor IA CPU
if not exist ".venv\Scripts\python.exe" (
 echo Execute INSTALAR_TIGER_312.bat primeiro.
 pause
 exit /b 1
)
call ".venv\Scripts\activate.bat"

echo ==========================================================
echo      TIGER 3D AI v1.6.7 - TRIPOSR CPU
echo ==========================================================
echo.
python -c "import urllib.request; urllib.request.urlopen('https://pypi.org',timeout=20); print('Internet/PyPI OK')"
if errorlevel 1 goto NETWORK_FAIL

python -m pip install --upgrade setuptools wheel --retries 8 --timeout 120
if errorlevel 1 goto FAIL
python -m pip install --index-url https://download.pytorch.org/whl/cpu --only-binary=:all: torch torchvision --retries 8 --timeout 120
if errorlevel 1 goto FAIL
python -m pip install --only-binary=:all: onnxruntime==1.22.0 tokenizers==0.15.2 --retries 8 --timeout 120
if errorlevel 1 goto FAIL
python -m pip install "transformers==4.36.2" "omegaconf==2.3.0" "Pillow==10.1.0" "einops==0.7.0" "huggingface-hub" "imageio[ffmpeg]" "rembg" "xatlas==0.0.9" "moderngl==5.10.0" "PyMCubes==0.1.6" --retries 8 --timeout 120
if errorlevel 1 goto FAIL
echo Corrigindo compatibilidade NumPy/SciPy...
python -m pip install --force-reinstall --only-binary=:all: "numpy==1.26.4" "scipy==1.12.0" --retries 8 --timeout 120
if errorlevel 1 goto FAIL

if not exist "TripoSR\run.py" (
 echo Baixando codigo do TripoSR com tentativas alternativas...
 if exist "TripoSR" rmdir /s /q "TripoSR"
 if exist "TripoSR-main" rmdir /s /q "TripoSR-main"
 if exist "triposr.zip" del /q "triposr.zip"

 rem Metodo 1: git clone via github.com, evita o host codeload.github.com
 where git >nul 2>nul
 if not errorlevel 1 (
   git -c http.version=HTTP/1.1 clone --depth 1 https://github.com/VAST-AI-Research/TripoSR.git TripoSR
   if exist "TripoSR\run.py" goto TRIPOSR_READY
   if exist "TripoSR" rmdir /s /q "TripoSR"
 )

 rem Metodo 2: download ZIP com retries e timeout maior
 powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; $urls=@('https://github.com/VAST-AI-Research/TripoSR/archive/refs/heads/main.zip','https://api.github.com/repos/VAST-AI-Research/TripoSR/zipball/main'); $ok=$false; foreach($u in $urls){ for($i=1;$i -le 3;$i++){ try { Write-Host ('Tentativa '+$i+': '+$u); Invoke-WebRequest -UseBasicParsing -Headers @{'User-Agent'='TIGER-3D-AI-Installer/1.6.6'} -Uri $u -OutFile 'triposr.zip' -TimeoutSec 180; if((Get-Item 'triposr.zip').Length -gt 100000){$ok=$true;break} } catch { Write-Host ('Falhou: '+$_.Exception.Message); Start-Sleep -Seconds 3 } }; if($ok){break} }; if(-not $ok){exit 2}"
 if errorlevel 1 goto NETWORK_FAIL
 if not exist "triposr.zip" goto NETWORK_FAIL
 powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; Expand-Archive -Path 'triposr.zip' -DestinationPath 'triposr_extract' -Force"
 if errorlevel 1 goto FAIL
 for /d %%D in (triposr_extract\VAST-AI-Research-TripoSR-*) do if exist "%%D\run.py" move "%%D" "TripoSR" >nul
 for /d %%D in (triposr_extract\TripoSR-main) do if exist "%%D\run.py" move "%%D" "TripoSR" >nul
 if exist "triposr_extract" rmdir /s /q "triposr_extract"
 if exist "triposr.zip" del /q "triposr.zip"
)

:TRIPOSR_READY
if not exist "TripoSR\run.py" goto NETWORK_FAIL

>TripoSR\torchmcubes.py echo import numpy as np
>>TripoSR\torchmcubes.py echo import torch
>>TripoSR\torchmcubes.py echo import mcubes
>>TripoSR\torchmcubes.py echo def marching_cubes(volume, level=0.0):
>>TripoSR\torchmcubes.py echo     if hasattr(volume, 'detach'): volume=volume.detach().cpu().numpy()
>>TripoSR\torchmcubes.py echo     v,f=mcubes.marching_cubes(np.asarray(volume),level)
>>TripoSR\torchmcubes.py echo     return torch.as_tensor(v,dtype=torch.float32),torch.as_tensor(f,dtype=torch.long)
>>TripoSR\torchmcubes.py echo def sparse_marching_cubes(volume, level=0.0): return marching_cubes(volume,level)

python -c "import numpy,scipy; print('NumPy',numpy.__version__); print('SciPy',scipy.__version__); assert numpy.__version__.startswith('1.26.') and scipy.__version__.startswith('1.12.')"
if errorlevel 1 goto FAIL
python -c "import torch,onnxruntime,rembg,pymatting; print('PyTorch',torch.__version__); print('ONNX Runtime',onnxruntime.__version__); print('rembg OK'); print('pymatting OK')"
if errorlevel 1 goto FAIL
>TRIPOSR_CPU_OK.txt echo INSTALADO=SIM
>>TRIPOSR_CPU_OK.txt echo MODO=CPU
>>TRIPOSR_CPU_OK.txt echo VERSAO=v1.6.7

echo.
echo ==========================================================
echo MOTOR IA INSTALADO COM SUCESSO!
echo Abra o TIGER com ABRIR_TIGER.bat
echo ==========================================================
pause
exit /b 0

:NETWORK_FAIL
echo.
echo ==========================================================
echo NAO FOI POSSIVEL BAIXAR O TRIPOSR DO GITHUB.
echo Teste o arquivo DIAGNOSTICO_REDE_GITHUB.bat.
echo O erro pode ser DNS, proxy, firewall ou internet.
echo O instalador tentou git clone e URLs ZIP alternativas.
echo ==========================================================
goto END_FAIL

:FAIL
echo.
echo ==========================================================
echo ERRO NA INSTALACAO DA IA.
echo Tire uma foto desta janela e envie aqui.
echo ==========================================================
:END_FAIL
pause
exit /b 1
